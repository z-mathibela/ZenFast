import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    viewBox="0 0 256 256" 
    xmlns="http://www.w3.org/2000/svg" 
    className={className}
    fill="currentColor"
  >
    {/* Background Circle (Optional, usually handled by container, but ensures shape) */}
    <path 
        d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Z" 
        className="opacity-20"
    />
    
    {/* Spiral/Zen Swirl Shapes */}
    <path d="M128,72c-30.93,0-56,25.07-56,56a8,8,0,0,1-16,0c0-39.76,32.24-72,72-72s72,32.24,72,72a8,8,0,0,1-16,0C184,97.07,158.93,72,128,72Z" />
    <path d="M128,104c-13.25,0-24,10.75-24,24a8,8,0,0,1-16,0c0-22.09,17.91-40,40-40s40,17.91,40,40a8,8,0,0,1-16,0C152,114.75,141.25,104,128,104Z" />
    <path d="M168,128a8,8,0,0,1,8,8c0,48.6-39.4,88-88,88a8,8,0,0,1,0-16c39.76,0,72-32.24,72-72A8,8,0,0,1,168,128Z" />
    <path d="M200,128a8,8,0,0,1,8,8c0,66.27-53.73,120-120,120a8,8,0,0,1,0-16c57.44,0,104-46.56,104-104A8,8,0,0,1,200,128Z" />
  </svg>
);