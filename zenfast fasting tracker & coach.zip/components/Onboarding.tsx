import React, { useState } from 'react';
import { Check, Clock, BarChart2, Sparkles, ChevronRight } from 'lucide-react';
import { FastingProtocol, ThemeClasses } from '../types';
import ProtocolSelector from './ProtocolSelector';
import { Logo } from './Logo';

interface OnboardingProps {
  onComplete: () => void;
  selectedProtocolId: string;
  onSelectProtocol: (p: FastingProtocol) => void;
  theme: ThemeClasses;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete, selectedProtocolId, onSelectProtocol, theme }) => {
  const [step, setStep] = useState(0);

  const nextStep = () => setStep(s => s + 1);

  const steps = [
    {
      id: 'welcome',
      title: 'Welcome to ZenFast',
      description: 'Your journey to better health, clarity, and discipline starts here.',
      content: (
        <div className="flex flex-col items-center justify-center py-8">
           <div className={`w-24 h-24 bg-gradient-to-tr ${theme.gradient} rounded-3xl flex items-center justify-center shadow-lg mb-6 animate-float p-4`}>
              <Logo className="w-full h-full text-white" />
           </div>
           <div className="text-center space-y-2">
              <p className="text-slate-300">
                ZenFast helps you track your intermittent fasting, analyze your progress, and stay motivated with AI coaching.
              </p>
           </div>
        </div>
      )
    },
    {
      id: 'features',
      title: 'Powerful Tools',
      description: 'Everything you need to succeed in one place.',
      content: (
        <div className="grid grid-cols-1 gap-4 py-4">
           <div className="flex items-start gap-4 p-4 bg-slate-800/50 rounded-xl border border-slate-700">
              <div className={`p-2 ${theme.subtleBg} rounded-lg ${theme.primary}`}>
                 <Clock className="w-6 h-6" />
              </div>
              <div>
                 <h4 className="font-bold text-white text-sm">Precision Timer</h4>
                 <p className="text-xs text-slate-400 mt-1">Track your fasting and eating windows with live progress updates.</p>
              </div>
           </div>
           <div className="flex items-start gap-4 p-4 bg-slate-800/50 rounded-xl border border-slate-700">
              <div className={`p-2 ${theme.subtleBg} rounded-lg ${theme.primary}`}>
                 <BarChart2 className="w-6 h-6" />
              </div>
              <div>
                 <h4 className="font-bold text-white text-sm">Deep Insights</h4>
                 <p className="text-xs text-slate-400 mt-1">Visualize your streaks, history, and consistency over time.</p>
              </div>
           </div>
           <div className="flex items-start gap-4 p-4 bg-slate-800/50 rounded-xl border border-slate-700">
              <div className={`p-2 ${theme.subtleBg} rounded-lg ${theme.primary}`}>
                 <Sparkles className="w-6 h-6" />
              </div>
              <div>
                 <h4 className="font-bold text-white text-sm">AI Coach</h4>
                 <p className="text-xs text-slate-400 mt-1">Get personalized tips and answers to your health questions.</p>
              </div>
           </div>
        </div>
      )
    },
    {
      id: 'setup',
      title: 'Choose Your Protocol',
      description: 'Select a fasting schedule that fits your lifestyle. You can change this anytime.',
      content: (
        <div className="py-2 max-h-[40vh] overflow-y-auto pr-1">
           <ProtocolSelector 
              selectedId={selectedProtocolId} 
              onSelect={onSelectProtocol} 
              theme={theme}
           />
        </div>
      )
    }
  ];

  const currentStep = steps[step];

  return (
    <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[100] flex items-center justify-center p-4 animate-in fade-in duration-300">
       <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md shadow-2xl flex flex-col max-h-[90vh]">
          
          {/* Header */}
          <div className="p-8 pb-0 text-center">
             <h2 className="text-2xl font-bold text-white mb-2">{currentStep.title}</h2>
             <p className="text-slate-400 text-sm">{currentStep.description}</p>
          </div>

          {/* Content */}
          <div className="p-8 flex-1 overflow-y-auto">
             {currentStep.content}
          </div>

          {/* Footer */}
          <div className="p-8 pt-0 mt-auto">
             <div className="flex items-center justify-between mb-6">
                <div className="flex gap-1.5">
                   {steps.map((_, idx) => (
                      <div 
                        key={idx} 
                        className={`h-1.5 rounded-full transition-all duration-300 ${idx === step ? `w-6 ${theme.bg}` : 'w-1.5 bg-slate-700'}`}
                      />
                   ))}
                </div>
             </div>

             <button
                onClick={step === steps.length - 1 ? onComplete : nextStep}
                className={`w-full py-4 ${theme.bg} ${theme.bgHover} text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 group`}
             >
                {step === steps.length - 1 ? (
                   <>
                     Get Started
                     <Check className="w-5 h-5" />
                   </>
                ) : (
                   <>
                     Next Step
                     <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                   </>
                )}
             </button>
          </div>

       </div>
    </div>
  );
};

export default Onboarding;
