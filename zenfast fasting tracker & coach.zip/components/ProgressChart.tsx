import React, { useMemo, useRef, useState } from 'react';
import { 
  ComposedChart, 
  Bar, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Cell, 
  CartesianGrid 
} from 'recharts';
import { Share2, Download, Loader2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import { FastingSession, ThemeClasses } from '../types';

interface ProgressChartProps {
  history: FastingSession[];
  theme?: ThemeClasses;
}

const ProgressChart: React.FC<ProgressChartProps> = ({ history, theme }) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const [isSharing, setIsSharing] = useState(false);

  const { data, consistency, avgDuration } = useMemo(() => {
    // Take the last 7 completed sessions, reverse to show oldest to newest
    const recentSessions = history
      .filter(session => session.endTime !== null)
      .slice(0, 7)
      .reverse();

    if (recentSessions.length === 0) {
      return { data: [], consistency: 0, avgDuration: 0 };
    }

    const chartData = recentSessions.map(session => {
        const startTime = new Date(session.startTime);
        const durationHours = session.endTime 
          ? (session.endTime - session.startTime) / (1000 * 60 * 60) 
          : 0;
        
        return {
          day: startTime.toLocaleDateString('en-US', { weekday: 'short' }),
          date: startTime.toLocaleDateString(),
          duration: parseFloat(durationHours.toFixed(1)),
          goal: session.targetDurationHours,
          isSuccess: durationHours >= session.targetDurationHours
        };
      });

    const successCount = chartData.filter(d => d.isSuccess).length;
    const consistencyScore = Math.round((successCount / chartData.length) * 100);
    
    const totalDuration = chartData.reduce((sum, d) => sum + d.duration, 0);
    const average = (totalDuration / chartData.length).toFixed(1);

    return { 
        data: chartData, 
        consistency: consistencyScore, 
        avgDuration: average 
    };
  }, [history]);

  const handleShare = async () => {
    if (!chartRef.current) return;
    setIsSharing(true);
    
    try {
        // Add a temporary padding/style to make the image look like a card
        const canvas = await html2canvas(chartRef.current, {
            backgroundColor: '#0f172a', // Ensure dark background
            scale: 2, // Higher quality
            logging: false
        });

        canvas.toBlob(async (blob) => {
            if (!blob) {
                setIsSharing(false);
                return;
            }

            const file = new File([blob], 'zenfast-progress.png', { type: 'image/png' });
            const shareData = {
                title: 'ZenFast Progress',
                text: `I've been consistent with my fasting! 🚀\nConsistency: ${consistency}%\nAvg Fast: ${avgDuration}h`,
                files: [file]
            };

            // Try Web Share API
            if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
                try {
                    await navigator.share(shareData);
                } catch (error) {
                    if (error instanceof Error && error.name !== 'AbortError') {
                         console.error('Error sharing:', error);
                    }
                }
            } else {
                // Fallback to download
                const link = document.createElement('a');
                link.download = 'zenfast-progress.png';
                link.href = canvas.toDataURL();
                link.click();
            }
            setIsSharing(false);
        }, 'image/png');

    } catch (error) {
        console.error("Failed to generate image", error);
        setIsSharing(false);
    }
  };

  if (data.length === 0) {
    return (
      <div className="h-48 flex items-center justify-center border border-slate-800 rounded-xl bg-slate-900/50 mb-6">
        <p className="text-slate-500 text-sm">Complete a fast to see your stats</p>
      </div>
    );
  }

  // Calculate max domain for Y axis to give some headroom
  const maxDuration = Math.max(...data.map(d => d.duration), ...data.map(d => d.goal));
  const themeColor = theme ? theme.chart : '#3b82f6';

  return (
    <div ref={chartRef} className="w-full bg-slate-900/50 border border-slate-800 rounded-xl p-5 mb-6 shadow-sm relative group">
      <div className="flex items-start justify-between mb-6">
        <div>
            <h3 className="text-slate-100 text-sm font-bold flex items-center gap-2">
                Weekly Progress
            </h3>
            <p className="text-xs text-slate-500 mt-1">Last 7 sessions</p>
        </div>
        
        <div className="flex items-center gap-4">
            <div className="hidden sm:flex gap-4">
                <div className="text-right">
                    <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Consistency</div>
                    <div className={`text-lg font-bold ${consistency >= 80 ? 'text-emerald-400' : consistency >= 50 ? 'text-orange-400' : 'text-slate-200'}`}>
                        {consistency}%
                    </div>
                </div>
                <div className="text-right">
                    <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Avg Time</div>
                    <div className={`text-lg font-bold ${theme ? theme.primary : 'text-blue-400'}`}>
                        {avgDuration}<span className={`text-xs ml-0.5 opacity-70`}>h</span>
                    </div>
                </div>
            </div>

            <button 
                onClick={handleShare}
                disabled={isSharing}
                className="p-2 text-slate-500 hover:text-white hover:bg-slate-800 rounded-full transition-all disabled:opacity-50"
                title="Share Progress"
            >
                {isSharing ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                    <Share2 className="w-5 h-5" />
                )}
            </button>
        </div>
      </div>

      <div className="h-56 w-full">
        <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data} margin={{ top: 10, right: 5, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
            <XAxis 
                dataKey="day" 
                tick={{ fill: '#64748b', fontSize: 11 }} 
                axisLine={false}
                tickLine={false}
                dy={10}
            />
            <YAxis 
                tick={{ fill: '#64748b', fontSize: 11 }} 
                axisLine={false}
                tickLine={false}
                domain={[0, Math.ceil(maxDuration + 2)]}
            />
            <Tooltip 
                cursor={{ fill: '#1e293b', opacity: 0.4 }}
                contentStyle={{ 
                backgroundColor: '#0f172a', 
                borderColor: '#334155', 
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                color: '#f1f5f9',
                fontSize: '12px'
                }}
                itemStyle={{ padding: 0 }}
                formatter={(value: number, name: string) => {
                    if (name === 'duration') return [`${value}h`, 'Actual Fast'];
                    if (name === 'goal') return [`${value}h`, 'Target Goal'];
                    return [value, name];
                }}
                labelStyle={{ color: '#94a3b8', marginBottom: '8px', fontWeight: 600 }}
            />
            <Bar dataKey="duration" radius={[4, 4, 0, 0]} maxBarSize={32}>
                {data.map((entry, index) => (
                <Cell 
                    key={`cell-${index}`} 
                    fill={entry.isSuccess ? themeColor : '#f97316'} 
                    fillOpacity={0.8}
                    className="transition-all duration-300 hover:opacity-100"
                />
                ))}
            </Bar>
            <Line 
                type="monotone" 
                dataKey="goal" 
                stroke="#64748b" 
                strokeWidth={2} 
                dot={{r: 3, fill: '#0f172a', stroke: '#64748b', strokeWidth: 2}} 
                activeDot={{r: 5, fill: '#64748b', stroke: '#fff'}}
                strokeDasharray="4 4"
            />
            </ComposedChart>
        </ResponsiveContainer>
      </div>
      
      <div className="flex justify-center items-center gap-6 mt-4 text-[10px] text-slate-500">
         <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: themeColor }}></div>
            <span>Goal Met</span>
         </div>
         <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
            <span>Missed</span>
         </div>
         <div className="flex items-center gap-1.5">
            <div className="w-3 h-0.5 bg-slate-500 border-t border-dashed border-slate-500"></div>
            <span>Target</span>
         </div>
      </div>
    </div>
  );
};

export default ProgressChart;