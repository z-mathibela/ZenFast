import React, { useState } from 'react';
import { Plus, ArrowRight, Mail, Lock, Loader2, ArrowLeft } from 'lucide-react';
import { UserProfile, AVATARS, THEME_COLORS, ThemeClasses } from '../types';
import { Logo } from './Logo';

interface AuthScreenProps {
  profiles: UserProfile[];
  onLogin: (profile: UserProfile) => void;
  onCreateProfile: (name: string, avatar: string, email?: string, provider?: 'email' | 'google' | 'apple') => void;
}

// Custom Icons for Social Providers
const GoogleIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
    <path
      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      fill="#4285F4"
    />
    <path
      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      fill="#34A853"
    />
    <path
      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
      fill="#FBBC05"
    />
    <path
      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
      fill="#EA4335"
    />
  </svg>
);

const AppleIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white" aria-hidden="true">
    <path d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.127 3.675-.552 9.127 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701" />
  </svg>
);

const AuthScreen: React.FC<AuthScreenProps> = ({ profiles, onLogin, onCreateProfile }) => {
  // 'selection' = Profile Picker (if profiles exist)
  // 'auth' = Login/Signup Landing
  // 'setup' = Name/Avatar config after auth
  const [view, setView] = useState<'selection' | 'auth' | 'setup'>(profiles.length > 0 ? 'selection' : 'auth');
  
  // Auth Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Setup Profile State
  const [newName, setNewName] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATARS[0]);
  const [authProvider, setAuthProvider] = useState<'email' | 'google' | 'apple'>('email');

  // Derived theme for preview
  const previewTheme: ThemeClasses = THEME_COLORS[selectedAvatar.color];

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Check if email exists in local profiles
    const existingProfile = profiles.find(p => p.email === email);

    if (existingProfile && !isSignUp) {
        // Successful Login
        onLogin(existingProfile);
    } else if (existingProfile && isSignUp) {
        // Error: Account exists
        alert("An account with this email already exists. Please log in.");
        setIsSignUp(false);
        setIsLoading(false);
    } else {
        // Proceed to setup profile
        setAuthProvider('email');
        setView('setup');
        setIsLoading(false);
    }
  };

  const handleSocialLogin = async (provider: 'google' | 'apple') => {
      setIsLoading(true);
      // Simulate OAuth popup/redirect
      await new Promise(resolve => setTimeout(resolve, 1200));
      
      // In a real app, we'd get the user info here. 
      // For this demo, we assume it's a new user or match by a mock ID.
      // Let's just go to setup for the demo experience unless we match a "mock" email.
      
      setAuthProvider(provider);
      setNewName(provider === 'google' ? 'Google User' : 'Apple User');
      setView('setup');
      setIsLoading(false);
  };

  const handleProfileSetupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newName.trim()) {
      onCreateProfile(newName.trim(), selectedAvatar.emoji, email, authProvider);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background Elements */}
      <div className={`absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full blur-3xl opacity-20 ${view === 'setup' ? previewTheme.bg : 'bg-blue-600'}`}></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-slate-700/10 rounded-full blur-3xl"></div>

      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl relative z-10 animate-fade-in">
        
        {/* Header Branding */}
        <div className="text-center mb-8">
          {(view === 'auth' || view === 'selection') && (
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg mb-4 p-3">
                     <Logo className="w-full h-full text-white" />
                </div>
                <h1 className="text-2xl font-bold text-white mb-1">ZenFast</h1>
                <p className="text-slate-400 text-sm">
                    {view === 'selection' ? 'Who is fasting today?' : isSignUp ? 'Create your account' : 'Welcome back'}
                </p>
              </div>
          )}
          {view === 'setup' && (
              <>
                 <div className={`w-16 h-16 rounded-2xl mx-auto flex items-center justify-center mb-4 shadow-lg transition-all duration-500 bg-gradient-to-tr ${previewTheme.gradient} ${previewTheme.shadow}`}>
                    <span className="text-3xl font-bold text-white">{selectedAvatar.emoji}</span>
                 </div>
                 <h2 className="text-xl font-bold text-white">Complete Profile</h2>
                 <p className="text-slate-400 text-sm">Pick your style</p>
              </>
          )}
        </div>

        {/* --- VIEW 1: PROFILE SELECTION (Legacy/Quick Switch) --- */}
        {view === 'selection' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 max-h-60 overflow-y-auto pr-1">
              {profiles.map((profile) => {
                const avatarConfig = AVATARS.find(a => a.emoji === profile.avatar) || AVATARS[0];
                const theme = THEME_COLORS[avatarConfig.color];
                
                return (
                  <button
                    key={profile.id}
                    onClick={() => onLogin(profile)}
                    className="p-4 bg-slate-800 hover:bg-slate-750 border border-slate-700 hover:border-slate-600 rounded-xl transition-all group text-left flex flex-col gap-2 relative overflow-hidden"
                  >
                    <div className={`absolute inset-0 opacity-0 group-hover:opacity-5 bg-gradient-to-tr ${theme.gradient}`} />
                    <span className="text-3xl filter grayscale group-hover:grayscale-0 transition-all duration-300 relative z-10">
                      {profile.avatar}
                    </span>
                    <span className="font-medium text-slate-200 group-hover:text-white truncate w-full relative z-10">
                      {profile.name}
                    </span>
                  </button>
                );
              })}
              
              <button
                onClick={() => setView('auth')}
                className="p-4 border-2 border-dashed border-slate-700 hover:border-slate-600 hover:bg-slate-800/50 rounded-xl transition-all flex flex-col items-center justify-center gap-2 group text-slate-500 hover:text-slate-300"
              >
                <div className="w-8 h-8 rounded-full bg-slate-800 group-hover:bg-slate-700 flex items-center justify-center transition-colors">
                  <Plus className="w-5 h-5" />
                </div>
                <span className="text-sm font-medium">Add Account</span>
              </button>
            </div>
            
            <button 
                onClick={() => setView('auth')}
                className="w-full py-3 mt-4 text-slate-400 hover:text-white text-sm font-medium transition-colors"
            >
                Log in with another account
            </button>
          </div>
        )}

        {/* --- VIEW 2: AUTH LANDING (Login/Signup) --- */}
        {view === 'auth' && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-300">
                {/* Social Login Buttons */}
                <div className="space-y-3 mb-6">
                    <button 
                        onClick={() => handleSocialLogin('google')}
                        disabled={isLoading}
                        className="w-full bg-white hover:bg-gray-100 text-slate-900 font-medium py-3 rounded-xl flex items-center justify-center gap-3 transition-colors shadow-sm disabled:opacity-70"
                    >
                        {isLoading ? <Loader2 className="w-5 h-5 animate-spin text-slate-600" /> : <GoogleIcon />}
                        Continue with Google
                    </button>
                    <button 
                        onClick={() => handleSocialLogin('apple')}
                        disabled={isLoading}
                        className="w-full bg-black hover:bg-slate-900 text-white font-medium py-3 rounded-xl flex items-center justify-center gap-3 transition-colors shadow-lg border border-slate-800 disabled:opacity-70"
                    >
                        {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <AppleIcon />}
                        Continue with Apple
                    </button>
                </div>

                <div className="relative flex items-center justify-center mb-6">
                    <div className="absolute inset-0 flex items-center">
                         <div className="w-full border-t border-slate-700/50"></div>
                    </div>
                    <span className="relative bg-slate-900 px-3 text-xs text-slate-500 uppercase tracking-wider font-semibold">
                        Or continue with email
                    </span>
                </div>

                {/* Email Form */}
                <form onSubmit={handleAuthSubmit} className="space-y-4">
                    <div className="space-y-1">
                        <div className="relative">
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="Email address"
                                className="w-full bg-slate-800/50 border border-slate-700 rounded-xl px-4 py-3 pl-10 text-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all placeholder-slate-500"
                                required
                            />
                            <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        </div>
                    </div>
                    <div className="space-y-1">
                        <div className="relative">
                            <input
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                placeholder={isSignUp ? "Create password" : "Password"}
                                className="w-full bg-slate-800/50 border border-slate-700 rounded-xl px-4 py-3 pl-10 text-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all placeholder-slate-500"
                                required
                            />
                            <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        </div>
                    </div>
                    
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl shadow-lg shadow-blue-900/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                        {isLoading ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                        ) : (
                            <>
                                {isSignUp ? 'Create Account' : 'Sign In'}
                                <ArrowRight className="w-4 h-4" />
                            </>
                        )}
                    </button>
                </form>

                <div className="mt-6 text-center space-y-4">
                    <button 
                        onClick={() => setIsSignUp(!isSignUp)}
                        className="text-sm text-slate-400 hover:text-white transition-colors"
                    >
                        {isSignUp ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
                    </button>
                    
                    {profiles.length > 0 && (
                         <button 
                            onClick={() => setView('selection')}
                            className="block w-full text-xs text-slate-500 hover:text-slate-300 pt-2 border-t border-slate-800 mt-2"
                        >
                            Back to profiles
                        </button>
                    )}
                </div>
            </div>
        )}

        {/* --- VIEW 3: PROFILE SETUP (Avatar/Name) --- */}
        {view === 'setup' && (
          <form onSubmit={handleProfileSetupSubmit} className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
             <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                Choose an Avatar
              </label>
              <div className="grid grid-cols-6 gap-2">
                {AVATARS.map((config) => {
                  const isSelected = selectedAvatar.emoji === config.emoji;
                  const theme = THEME_COLORS[config.color];
                  return (
                    <button
                      key={config.emoji}
                      type="button"
                      onClick={() => setSelectedAvatar(config)}
                      className={`
                        aspect-square flex items-center justify-center text-2xl rounded-lg transition-all
                        ${isSelected
                          ? `${theme.subtleBg} ${theme.border} ring-1 ${theme.ring} scale-110` 
                          : 'bg-slate-800 border border-slate-700 hover:bg-slate-700'
                        }
                      `}
                    >
                      {config.emoji}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                Display Name
              </label>
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Enter your name"
                autoFocus
                className={`w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none transition-all placeholder-slate-600 focus:border-[color] focus:ring-1 focus:ring-[color]`}
                style={{ borderColor: newName ? undefined : '', '--tw-ring-color': previewTheme.chart } as React.CSSProperties}
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setView(profiles.length > 0 ? 'selection' : 'auth')}
                className="flex-1 py-3 px-4 rounded-xl font-semibold text-slate-400 hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button
                type="submit"
                disabled={!newName.trim()}
                className={`
                  flex-1 py-3 px-4 rounded-xl text-white font-semibold transition-all flex items-center justify-center gap-2
                  ${previewTheme.bg} ${previewTheme.bgHover} ${previewTheme.shadow}
                  disabled:opacity-50 disabled:cursor-not-allowed
                `}
              >
                Complete
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}
      </div>
      
      <div className="absolute bottom-6 text-center text-slate-600 text-xs">
        <p>Data stored locally. Demo authentication.</p>
      </div>
    </div>
  );
};

export default AuthScreen;
