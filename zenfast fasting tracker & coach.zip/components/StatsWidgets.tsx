import React, { useMemo } from 'react';
import { FastingSession, ThemeClasses } from '../types';
import { Flame, Clock, Hash, Trophy } from 'lucide-react';

interface StatsWidgetsProps {
  history: FastingSession[];
  streak: number;
  theme: ThemeClasses;
}

const StatsWidgets: React.FC<StatsWidgetsProps> = ({ history, streak, theme }) => {
  const stats = useMemo(() => {
    const completedSessions = history.filter(s => s.endTime !== null);
    const totalFasts = completedSessions.length;
    
    let totalHours = 0;
    let longestFast = 0;

    completedSessions.forEach(s => {
      if (s.endTime) {
        const duration = (s.endTime - s.startTime) / (1000 * 60 * 60);
        totalHours += duration;
        if (duration > longestFast) longestFast = duration;
      }
    });

    return {
      totalFasts,
      totalHours: totalHours.toFixed(0),
      longestFast: longestFast.toFixed(1)
    };
  }, [history]);

  return (
    <div className="grid grid-cols-2 gap-3 w-full animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Total Fasts Widget */}
      <div className={`bg-slate-800/40 border border-slate-700/50 rounded-2xl p-4 flex flex-col justify-between hover:bg-slate-800/60 transition-colors group`}>
        <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Total Fasts</span>
            <div className={`p-1.5 rounded-lg bg-slate-800 text-slate-400 group-hover:text-white transition-colors`}>
                <Hash className="w-3.5 h-3.5" />
            </div>
        </div>
        <div className="text-2xl font-bold text-white font-mono">
            {stats.totalFasts}
        </div>
      </div>

      {/* Total Hours Widget */}
      <div className={`bg-slate-800/40 border border-slate-700/50 rounded-2xl p-4 flex flex-col justify-between hover:bg-slate-800/60 transition-colors group`}>
        <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Total Hours</span>
            <div className={`p-1.5 rounded-lg bg-slate-800 ${theme.subtleText} group-hover:text-white transition-colors`}>
                <Clock className="w-3.5 h-3.5" />
            </div>
        </div>
        <div className={`text-2xl font-bold ${theme.primary} font-mono`}>
            {stats.totalHours}
        </div>
      </div>

      {/* Streak Widget */}
      <div className={`bg-slate-800/40 border border-slate-700/50 rounded-2xl p-4 flex flex-col justify-between hover:bg-slate-800/60 transition-colors group`}>
        <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Current Streak</span>
            <div className={`p-1.5 rounded-lg bg-slate-800 ${streak > 0 ? 'text-orange-500' : 'text-slate-400'} group-hover:text-white transition-colors`}>
                <Flame className={`w-3.5 h-3.5 ${streak > 0 ? 'fill-current' : ''}`} />
            </div>
        </div>
        <div className="text-2xl font-bold text-white font-mono">
            {streak} <span className="text-xs text-slate-500 font-sans font-normal">days</span>
        </div>
      </div>

      {/* Longest Fast Widget */}
      <div className={`bg-slate-800/40 border border-slate-700/50 rounded-2xl p-4 flex flex-col justify-between hover:bg-slate-800/60 transition-colors group`}>
        <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Longest Fast</span>
            <div className={`p-1.5 rounded-lg bg-slate-800 text-yellow-500 group-hover:text-white transition-colors`}>
                <Trophy className="w-3.5 h-3.5" />
            </div>
        </div>
        <div className="text-2xl font-bold text-white font-mono">
            {stats.longestFast}<span className="text-sm text-slate-500 ml-0.5">h</span>
        </div>
      </div>
    </div>
  );
};

export default StatsWidgets;
