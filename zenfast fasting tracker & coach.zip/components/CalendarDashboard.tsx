import React, { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight, X, Book, Clock, Calendar as CalendarIcon, Save, TrendingUp } from 'lucide-react';
import { FastingSession, ThemeClasses } from '../types';
import ProgressChart from './ProgressChart';

interface CalendarDashboardProps {
  history: FastingSession[];
  journal: Record<string, string>;
  onUpdateJournal: (date: string, text: string) => void;
  onClose: () => void;
  theme: ThemeClasses;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const CalendarDashboard: React.FC<CalendarDashboardProps> = ({ history, journal, onUpdateJournal, onClose, theme }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDateKey, setSelectedDateKey] = useState<string | null>(null);
  const [noteInput, setNoteInput] = useState("");
  const [viewMode, setViewMode] = useState<'calendar' | 'trends'>('calendar');

  // Helper: Format date to YYYY-MM-DD for keys
  const formatDateKey = (date: Date) => {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  };

  // Aggregate Data
  const dailyStats = useMemo(() => {
    const stats: Record<string, { totalHours: number; sessions: FastingSession[] }> = {};
    
    history.forEach(session => {
      if (!session.endTime) return;
      const end = new Date(session.endTime);
      const key = formatDateKey(end);
      
      if (!stats[key]) {
        stats[key] = { totalHours: 0, sessions: [] };
      }
      
      const duration = (session.endTime - session.startTime) / (1000 * 60 * 60);
      stats[key].totalHours += duration;
      stats[key].sessions.push(session);
    });

    return stats;
  }, [history]);

  // Calendar Logic
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = new Date(year, month, 1).getDay();

  const handlePrevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const handleNextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

  const handleDayClick = (day: number) => {
    const date = new Date(year, month, day);
    const key = formatDateKey(date);
    setSelectedDateKey(key);
    setNoteInput(journal[key] || "");
  };

  const saveJournal = () => {
    if (selectedDateKey) {
      onUpdateJournal(selectedDateKey, noteInput);
    }
  };

  const renderCalendarCells = () => {
    const cells = [];
    
    // Empty cells for previous month
    for (let i = 0; i < firstDayOfMonth; i++) {
      cells.push(<div key={`empty-${i}`} className="h-24 bg-slate-900/30 border-b border-r border-slate-800/50" />);
    }

    // Days
    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, month, d);
      const key = formatDateKey(date);
      const stats = dailyStats[key];
      const hasNote = !!journal[key];
      const isToday = formatDateKey(new Date()) === key;
      
      const hours = stats ? stats.totalHours : 0;
      // Cap bar height visually at ~20 hours for scale
      const barHeight = Math.min((hours / 20) * 100, 100); 

      cells.push(
        <button
          key={key}
          onClick={() => handleDayClick(d)}
          className={`
            h-24 relative border-b border-r border-slate-800/50 p-2 text-left transition-colors
            hover:bg-slate-800/50 flex flex-col justify-between items-start group
            ${isToday ? 'bg-slate-800/80' : ''}
          `}
        >
          <div className="flex justify-between w-full items-start">
            <span className={`text-sm font-medium ${isToday ? theme.primary : 'text-slate-400'}`}>
              {d}
            </span>
            {hasNote && <div className={`w-1.5 h-1.5 rounded-full ${theme.bg}`} />}
          </div>

          {/* Fasting Bar */}
          {hours > 0 && (
             <div className="w-full flex items-end gap-1 h-12 mt-1">
                 <div 
                    className={`w-full bg-gradient-to-t ${theme.gradient} rounded-t-sm opacity-80 group-hover:opacity-100 transition-all`}
                    style={{ height: `${barHeight}%` }}
                 />
             </div>
          )}
          
          {hours > 0 && (
            <span className="absolute bottom-1 right-1 text-[10px] text-slate-500 font-mono">
                {hours.toFixed(1)}h
            </span>
          )}
        </button>
      );
    }

    return cells;
  };

  // Selected Date Details
  const renderDayDetails = () => {
    if (!selectedDateKey) return null;
    
    const [y, m, d] = selectedDateKey.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    const stats = dailyStats[selectedDateKey];
    const displayDate = dateObj.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

    return (
      <div className="absolute inset-0 bg-slate-900/95 backdrop-blur-sm z-20 flex justify-end">
        <div className="w-full max-w-sm bg-slate-900 border-l border-slate-700 h-full p-6 overflow-y-auto animate-slide-in-right flex flex-col">
            
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-bold text-slate-100">{displayDate}</h3>
                <button 
                    onClick={() => { saveJournal(); setSelectedDateKey(null); }}
                    className="p-2 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white"
                >
                    <X className="w-6 h-6" />
                </button>
            </div>

            {/* Summary Card */}
            <div className="bg-slate-800/50 rounded-2xl p-6 mb-8 border border-slate-700">
                <div className="text-slate-400 text-sm font-medium uppercase tracking-wider mb-1">Total Fasting</div>
                <div className="text-4xl font-bold text-white mb-2">
                    {stats?.totalHours.toFixed(1) || '0.0'}
                    <span className="text-lg text-slate-500 font-normal ml-1">hours</span>
                </div>
                {stats && (
                    <div className="text-xs text-slate-500">
                        {stats.sessions.length} session{stats.sessions.length !== 1 && 's'} completed
                    </div>
                )}
            </div>

            {/* Journal Section */}
            <div className="flex-1 flex flex-col mb-8">
                <div className={`flex items-center gap-2 mb-3 ${theme.primary}`}>
                    <Book className="w-5 h-5" />
                    <h4 className="font-semibold">Daily Journal</h4>
                </div>
                <textarea
                    value={noteInput}
                    onChange={(e) => setNoteInput(e.target.value)}
                    placeholder="How did you feel today? Any challenges or wins?"
                    className={`w-full flex-1 bg-slate-800/30 border border-slate-700 rounded-xl p-4 text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-1 ${theme.ring} focus:border-transparent resize-none text-sm leading-relaxed`}
                />
                {noteInput !== (journal[selectedDateKey] || "") && (
                    <button 
                        onClick={saveJournal}
                        className={`mt-3 flex items-center justify-center gap-2 w-full py-2 ${theme.bg} ${theme.bgHover} text-white rounded-lg text-sm font-semibold transition-colors`}
                    >
                        <Save className="w-4 h-4" />
                        Save Note
                    </button>
                )}
            </div>

            {/* Session List */}
            {stats && stats.sessions.length > 0 && (
                <div>
                     <div className={`flex items-center gap-2 mb-3 ${theme.primary}`}>
                        <Clock className="w-5 h-5" />
                        <h4 className="font-semibold">Sessions</h4>
                    </div>
                    <div className="space-y-3">
                        {stats.sessions.map(session => (
                            <div key={session.id} className="p-3 bg-slate-800/30 border border-slate-700/50 rounded-lg">
                                <div className="flex justify-between items-center mb-1">
                                    <span className="text-slate-300 font-medium text-sm">{session.protocolName}</span>
                                    <span className={`font-mono text-sm font-bold ${theme.primary}`}>
                                        {((session.endTime! - session.startTime) / 3600000).toFixed(1)}h
                                    </span>
                                </div>
                                <div className="text-xs text-slate-500">
                                    {new Date(session.startTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} - {new Date(session.endTime!).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-slate-900 z-50 overflow-hidden flex flex-col animate-in fade-in duration-200">
        
        {/* Top Navigation */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900">
            <h2 className="text-xl font-bold flex items-center gap-2">
                {viewMode === 'calendar' ? <CalendarIcon className={`w-6 h-6 ${theme.primary}`} /> : <TrendingUp className={`w-6 h-6 ${theme.primary}`} />}
                {viewMode === 'calendar' ? 'Calendar' : 'Trends'}
            </h2>
            
            <div className="flex bg-slate-800 rounded-lg p-1 border border-slate-700">
                <button 
                    onClick={() => setViewMode('calendar')} 
                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${viewMode === 'calendar' ? `${theme.bg} text-white shadow-lg` : 'text-slate-400 hover:text-white'}`}
                >
                    Calendar
                </button>
                <button 
                    onClick={() => setViewMode('trends')} 
                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${viewMode === 'trends' ? `${theme.bg} text-white shadow-lg` : 'text-slate-400 hover:text-white'}`}
                >
                    Trends
                </button>
            </div>

            <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors">
                <X className="w-6 h-6 text-slate-400" />
            </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
            <div className="max-w-4xl mx-auto">
                
                {viewMode === 'calendar' ? (
                    <>
                        {/* Month Navigator */}
                        <div className="flex items-center justify-between mb-6">
                            <button onClick={handlePrevMonth} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white">
                                <ChevronLeft className="w-6 h-6" />
                            </button>
                            <div className="text-2xl font-bold text-white">
                                {MONTHS[month]} {year}
                            </div>
                            <button onClick={handleNextMonth} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white">
                                <ChevronRight className="w-6 h-6" />
                            </button>
                        </div>

                        {/* Grid */}
                        <div className="w-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
                            {/* Days Header */}
                            <div className="grid grid-cols-7 border-b border-slate-800 bg-slate-800/50">
                                {DAYS.map(day => (
                                    <div key={day} className="py-3 text-center text-xs font-semibold text-slate-500 uppercase tracking-wider">
                                        {day}
                                    </div>
                                ))}
                            </div>
                            
                            {/* Calendar Cells */}
                            <div className="grid grid-cols-7">
                                {renderCalendarCells()}
                            </div>
                        </div>

                        <div className="mt-6 flex justify-center gap-6 text-sm text-slate-500">
                            <div className="flex items-center gap-2">
                                <div className={`w-3 h-3 rounded-full ${theme.bg}`}></div>
                                <span>Fasting Time</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <div className={`w-3 h-3 rounded-full ${theme.bg}`}></div>
                                <span>Journal Entry</span>
                            </div>
                        </div>
                    </>
                ) : (
                    // Trends View
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <div className="mb-6">
                            <h3 className="text-xl font-bold text-white mb-2">Progress Overview</h3>
                            <p className="text-slate-400 text-sm">Visualize your performance and share your wins.</p>
                        </div>
                        
                        <ProgressChart history={history} theme={theme} />
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
                            <div className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-6">
                                <h4 className="text-slate-300 font-semibold mb-2 flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                                    Consistency is Key
                                </h4>
                                <p className="text-sm text-slate-400 leading-relaxed">
                                    Tracking your fasts helps build habit loops. Use the share button on the chart to celebrate your streaks with friends!
                                </p>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>

        {/* Day Details Overlay */}
        {renderDayDetails()}
    </div>
  );
};

export default CalendarDashboard;