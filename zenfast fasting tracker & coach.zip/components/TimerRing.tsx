import React from 'react';
import { ThemeClasses } from '../types';

interface TimerRingProps {
  progress: number; // 0 to 100
  size?: number;
  strokeWidth?: number;
  isFasting: boolean;
  theme: ThemeClasses;
  children?: React.ReactNode;
}

const TimerRing: React.FC<TimerRingProps> = ({
  progress,
  size = 300,
  strokeWidth = 12,
  isFasting,
  theme,
  children
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  
  // Ensure progress is between 0 and 100
  const normalizedProgress = Math.min(Math.max(progress, 0), 100);
  const strokeDashoffset = circumference - (normalizedProgress / 100) * circumference;

  // If not fasting (completed or idle), use standard emerald green for success or neutral
  const colorClass = isFasting ? theme.primary : "text-slate-700";
  const glowClass = isFasting ? theme.glow : "";

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      {/* Background Circle */}
      <svg
        height={size}
        width={size}
        className="transform -rotate-90"
      >
        <circle
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
          className="text-slate-800"
        />
        {/* Progress Circle */}
        <circle
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
          className={`${colorClass} transition-all duration-1000 ease-in-out`}
          style={{
            strokeDasharray: circumference + ' ' + circumference,
            strokeDashoffset: strokeDashoffset,
            strokeLinecap: 'round'
          }}
        />
      </svg>
      
      {/* Glow Effect behind the ring (simulated with absolute div) */}
      {isFasting && (
        <div 
            className={`absolute inset-0 rounded-full opacity-20 blur-xl ${theme.bg}`}
            style={{ transform: 'scale(0.85)', zIndex: -1 }}
        />
      )}

      {/* Content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        {children}
      </div>
    </div>
  );
};

export default TimerRing;