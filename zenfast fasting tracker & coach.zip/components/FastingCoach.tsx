import React, { useState } from 'react';
import { Sparkles, MessageSquare, Send } from 'lucide-react';
import { getFastingTip, askCoach } from '../services/geminiService';
import { ThemeClasses } from '../types';

interface FastingCoachProps {
  hoursFasted: number;
  targetHours: number;
  protocolName: string;
  isFasting: boolean;
  theme: ThemeClasses;
}

const MOODS = ['Energetic', 'Hungry', 'Tired', 'Focused', 'Bored'];

const MOOD_AVATARS: Record<string, string> = {
  'Energetic': '⚡',
  'Hungry': '🍏',
  'Tired': '🌙',
  'Focused': '👁️',
  'Bored': '🎨',
  'Default': '🧘',
  'Thinking': '🤔'
};

const FastingCoach: React.FC<FastingCoachProps> = ({ hoursFasted, targetHours, protocolName, isFasting, theme }) => {
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [question, setQuestion] = useState("");

  const handleGetTip = async (mood: string) => {
    setSelectedMood(mood);
    setLoading(true);
    setResponse(null);
    const newTip = await getFastingTip(hoursFasted, targetHours, mood);
    setResponse(newTip);
    setLoading(false);
  };

  const handleAskQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    setLoading(true);
    setSelectedMood(null); // Reset mood for custom questions
    setResponse(null);
    
    const answer = await askCoach(question, hoursFasted, targetHours, protocolName);
    setResponse(answer);
    setLoading(false);
    setQuestion("");
  };

  if (!isFasting) return null;

  // Determine current avatar and state
  let currentAvatar = MOOD_AVATARS['Default'];
  let avatarState = 'idle';

  if (loading) {
      currentAvatar = MOOD_AVATARS['Thinking'];
      avatarState = 'loading';
  } else if (selectedMood) {
      currentAvatar = MOOD_AVATARS[selectedMood] || MOOD_AVATARS['Default'];
      avatarState = 'active';
  }

  return (
    <div className={`w-full max-w-md bg-gradient-to-br from-slate-900/50 to-slate-900/80 border ${theme.border} border-opacity-20 rounded-2xl p-6 relative overflow-hidden transition-all shadow-lg`}>
      <style>{`
        @keyframes float-subtle {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-4px); }
        }
        @keyframes breathe {
          0%, 100% { transform: scale(1); opacity: 0.3; }
          50% { transform: scale(1.1); opacity: 0.6; }
        }
        .animate-idle {
          animation: float-subtle 5s ease-in-out infinite;
        }
        .animate-breathe {
          animation: breathe 4s ease-in-out infinite;
        }
      `}</style>
      
      {/* Header with Dynamic Avatar */}
      <div className="flex items-center gap-5 mb-6">
        <div 
            className={`
                relative w-16 h-16 rounded-3xl flex items-center justify-center text-4xl 
                transition-all duration-700 cubic-bezier(0.34, 1.56, 0.64, 1) shadow-xl
                ${avatarState === 'loading' ? `scale-110 ${theme.subtleBg} ${theme.ring} ring-2 ring-offset-2 ring-offset-slate-900` : ''}
                ${avatarState === 'active' ? `${theme.bg} scale-100 ${theme.glow} text-white` : ''}
                ${avatarState === 'idle' ? 'bg-slate-800 border border-slate-700/60 animate-idle' : ''}
            `}
        >
            {/* Background glow for active state - enhanced */}
            {avatarState === 'active' && (
                 <div className={`absolute inset-0 rounded-3xl ${theme.bg} blur-lg opacity-50 -z-10 animate-pulse`} />
            )}
            
            {/* Idle Breathing Glow */}
             {avatarState === 'idle' && (
                 <div className={`absolute inset-0 rounded-3xl bg-slate-700/30 blur-md -z-10 animate-breathe`} />
            )}

            {/* Avatar Icon with Key-based Animation */}
            <span className="animate-in fade-in zoom-in-75 slide-in-from-bottom-2 duration-500 absolute inset-0 flex items-center justify-center drop-shadow-md" key={currentAvatar}>
                {currentAvatar}
            </span>

            {/* Loading Indicator Ring */}
            {loading && (
                <div className="absolute inset-0 rounded-3xl border-2 border-t-transparent border-r-transparent border-white/40 animate-spin" />
            )}
        </div>

        <div>
            <h3 className="text-slate-100 font-semibold flex items-center gap-2 text-lg">
                AI Coach
                {loading && <Sparkles className={`w-4 h-4 ${theme.primary} animate-spin`} />}
            </h3>
            <div className="h-5 overflow-hidden relative">
                <p className="text-xs text-slate-400 uppercase tracking-wider font-medium transition-all duration-300 animate-in slide-in-from-bottom-1" key={loading ? 'loading' : selectedMood || 'ready'}>
                    {loading ? 'Thinking...' : selectedMood ? `Mood: ${selectedMood}` : 'Ready to help'}
                </p>
            </div>
        </div>
      </div>

      <div className="space-y-4">
        {/* Mood Selector */}
        {!response && !loading && (
          <div className="animate-fade-in">
            <p className="text-slate-400 text-sm mb-3 font-medium">How are you feeling?</p>
            <div className="flex flex-wrap gap-2 mb-6">
              {MOODS.map((mood) => (
                <button
                  key={mood}
                  onClick={() => handleGetTip(mood)}
                  disabled={loading}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/50 hover:border-slate-600 text-slate-200 text-sm transition-all hover:-translate-y-0.5 disabled:opacity-50 flex items-center gap-2 group"
                >
                  <span className="group-hover:scale-125 transition-transform duration-200">{MOOD_AVATARS[mood]}</span>
                  {mood}
                </button>
              ))}
            </div>
            
            <div className="relative border-t border-slate-700/50 pt-5">
               <p className="text-slate-500 text-[10px] uppercase tracking-wider font-bold mb-3">Or ask a specific question</p>
               <form onSubmit={handleAskQuestion} className="flex gap-2">
                 <input
                    type="text"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    placeholder="e.g., Can I drink coffee?"
                    className={`flex-1 bg-slate-800/50 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:ring-1 ${theme.ring} focus:border-transparent placeholder-slate-600 transition-all`}
                 />
                 <button 
                    type="submit" 
                    disabled={!question.trim()}
                    className={`p-3 ${theme.bg} ${theme.bgHover} disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-xl transition-all hover:scale-105 active:scale-95 shadow-lg`}
                 >
                    <Send className="w-4 h-4" />
                 </button>
               </form>
            </div>
          </div>
        )}

        {/* Response Display */}
        {response && (
          <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
             <div className={`${theme.subtleBg} p-5 rounded-2xl border ${theme.border} border-opacity-30 relative shadow-inner`}>
                {/* Speech bubble triangle */}
                <div className={`absolute -top-2 left-8 w-4 h-4 ${theme.subtleBg} border-t ${theme.border} border-l ${theme.border} border-opacity-30 transform rotate-45`}></div>
                
                <p className="text-slate-100 text-sm leading-relaxed relative z-10 font-medium">
                  "{response}"
                </p>
             </div>
             
             <button 
               onClick={() => { setResponse(null); setSelectedMood(null); }}
               className={`mt-4 w-full py-3 flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-wider ${theme.primary} hover:bg-slate-800/50 rounded-xl transition-colors`}
             >
               <MessageSquare className="w-3 h-3" />
               Ask something else
             </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default FastingCoach;