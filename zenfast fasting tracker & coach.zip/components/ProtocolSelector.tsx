import React, { useState } from 'react';
import { Info, X, Check, ThumbsUp, ThumbsDown, Clock, Target } from 'lucide-react';
import { FastingProtocol, PROTOCOLS, ThemeClasses } from '../types';

interface ProtocolSelectorProps {
  selectedId: string;
  onSelect: (protocol: FastingProtocol) => void;
  disabled?: boolean;
  theme?: ThemeClasses;
}

const ProtocolSelector: React.FC<ProtocolSelectorProps> = ({ selectedId, onSelect, disabled, theme }) => {
  const [detailsProtocol, setDetailsProtocol] = useState<FastingProtocol | null>(null);
  
  // Local state for custom hours, initialized to default custom or current selected custom
  const [customHours, setCustomHours] = useState(12);

  const handleInfoClick = (e: React.MouseEvent, protocol: FastingProtocol) => {
    e.stopPropagation();
    setDetailsProtocol(protocol);
  };

  const handleCustomChange = (e: React.ChangeEvent<HTMLInputElement>, protocol: FastingProtocol) => {
    const hours = parseInt(e.target.value);
    setCustomHours(hours);
    onSelect({
        ...protocol,
        fastingHours: hours,
        eatingHours: 24 - (hours % 24), // Rough estimate for eating window or 0
        name: `Custom Fast (${hours}h)`
    });
  };

  return (
    <>
      <div className="grid grid-cols-1 gap-3 w-full max-w-md">
        <h3 className="text-slate-400 text-sm uppercase tracking-wider font-semibold mb-2">Select Protocol</h3>
        {PROTOCOLS.map((p) => {
          const isSelected = selectedId === p.id || (p.isCustom && selectedId === 'custom');
          
          let containerClass = "";
          if (isSelected && theme) {
             containerClass = `bg-slate-800 ${theme.border} ring-1 ${theme.ring} ${theme.shadow}`;
          } else {
             containerClass = `bg-slate-900/50 border-slate-700 hover:bg-slate-800`;
             if (!disabled) {
                containerClass += ` transform hover:scale-[1.02]`;
                if (theme) {
                    containerClass += ` hover:${theme.border} hover:${theme.shadow}`;
                } else {
                    containerClass += ` hover:border-slate-600`;
                }
             }
          }

          const badgeClass = isSelected && theme
              ? `${theme.bg} text-white`
              : 'bg-slate-800 text-slate-400';

          return (
              <div
                key={p.id}
                className={`relative rounded-xl border transition-all duration-200 ${containerClass} ${disabled ? 'opacity-50' : ''}`}
              >
                <button
                    onClick={() => !disabled && onSelect(p.isCustom ? { ...p, fastingHours: customHours, name: `Custom Fast (${customHours}h)` } : p)}
                    disabled={disabled}
                    className="w-full text-left p-4 pr-12"
                >
                    <div className="flex justify-between items-center mb-1">
                        <span className={`font-bold text-lg ${isSelected ? 'text-white' : 'text-slate-200'}`}>
                        {p.isCustom && isSelected ? `Custom (${customHours}h)` : p.name}
                        </span>
                        {!p.isCustom && (
                            <span className={`text-xs font-mono px-2 py-1 rounded-full ${badgeClass}`}>
                            {p.id}
                            </span>
                        )}
                    </div>
                    <p className="text-sm text-slate-400">{p.description}</p>
                </button>

                {/* Info Button */}
                <button 
                    onClick={(e) => handleInfoClick(e, p)}
                    className="absolute top-4 right-3 p-1.5 text-slate-500 hover:text-slate-200 hover:bg-slate-700/50 rounded-full transition-colors z-10"
                    title="View Details"
                >
                    <Info className="w-5 h-5" />
                </button>

                {/* Custom Slider Integration */}
                {p.isCustom && isSelected && (
                    <div className="px-4 pb-4 animate-in fade-in slide-in-from-top-1">
                         <div className="flex items-center justify-between text-xs text-slate-400 mb-2 font-mono">
                             <span>1h</span>
                             <span>{customHours} hours</span>
                             <span>168h</span>
                         </div>
                         <input 
                            type="range" 
                            min="1" 
                            max="168" 
                            value={customHours}
                            onChange={(e) => handleCustomChange(e, p)}
                            className={`w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-${theme?.primary.replace('text-', '')?.replace('-500', '') || 'blue'}-500`}
                         />
                    </div>
                )}
              </div>
          );
        })}
      </div>

      {/* Info Modal */}
      {detailsProtocol && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200" onClick={() => setDetailsProtocol(null)}>
           <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-sm shadow-2xl overflow-hidden flex flex-col max-h-[85vh]" onClick={e => e.stopPropagation()}>
                
                {/* Header */}
                <div className="p-5 border-b border-slate-800 flex justify-between items-start bg-slate-800/30">
                    <div>
                        <h3 className="text-xl font-bold text-white mb-1">{detailsProtocol.name}</h3>
                        <div className="flex items-center gap-3 text-sm text-slate-400">
                             <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {detailsProtocol.fastingHours}h Fast</span>
                             {detailsProtocol.eatingHours > 0 && <span>• {detailsProtocol.eatingHours}h Eat</span>}
                        </div>
                    </div>
                    <button onClick={() => setDetailsProtocol(null)} className="p-1 hover:bg-slate-700 rounded-full text-slate-400 hover:text-white">
                        <X className="w-5 h-5" />
                    </button>
                </div>

                {/* Content */}
                <div className="p-6 overflow-y-auto space-y-6">
                    {/* What & Who */}
                    <div className="space-y-4">
                        <div>
                            <h4 className={`text-sm font-bold uppercase tracking-wider mb-2 ${theme ? theme.primary : 'text-blue-500'}`}>What is it?</h4>
                            <p className="text-slate-300 text-sm leading-relaxed">{detailsProtocol.detailedInfo?.whatIsIt}</p>
                        </div>
                        <div>
                            <h4 className={`text-sm font-bold uppercase tracking-wider mb-2 ${theme ? theme.primary : 'text-blue-500'}`}>Who is it for?</h4>
                            <p className="text-slate-300 text-sm leading-relaxed">{detailsProtocol.detailedInfo?.whoIsItFor}</p>
                        </div>
                    </div>

                    {/* Pros & Cons */}
                    <div className="grid grid-cols-1 gap-4">
                        <div className="bg-emerald-900/10 border border-emerald-900/30 rounded-xl p-4">
                            <div className="flex items-center gap-2 mb-3 text-emerald-400 font-bold text-sm">
                                <ThumbsUp className="w-4 h-4" /> PROS
                            </div>
                            <ul className="space-y-2">
                                {detailsProtocol.detailedInfo?.pros?.map((pro, idx) => (
                                    <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                                        <Check className="w-3 h-3 text-emerald-500 mt-0.5 shrink-0" />
                                        <span>{pro}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        <div className="bg-rose-900/10 border border-rose-900/30 rounded-xl p-4">
                            <div className="flex items-center gap-2 mb-3 text-rose-400 font-bold text-sm">
                                <ThumbsDown className="w-4 h-4" /> CONS
                            </div>
                            <ul className="space-y-2">
                                {detailsProtocol.detailedInfo?.cons?.map((con, idx) => (
                                    <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                                        <div className="w-1 h-1 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                                        <span>{con}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </div>

                {/* Footer Action */}
                <div className="p-4 border-t border-slate-800 bg-slate-900">
                     <button 
                        onClick={() => { onSelect(detailsProtocol); setDetailsProtocol(null); }}
                        className={`w-full py-3 ${theme ? theme.bg : 'bg-blue-600'} ${theme ? theme.bgHover : 'hover:bg-blue-500'} text-white rounded-xl font-bold transition-all shadow-lg flex items-center justify-center gap-2`}
                     >
                        <Target className="w-4 h-4" />
                        Select This Protocol
                     </button>
                </div>
           </div>
        </div>
      )}
    </>
  );
};

export default ProtocolSelector;