import React, { useState } from 'react';
import { X, Save, User } from 'lucide-react';
import { UserProfile, AVATARS, THEME_COLORS } from '../types';

interface EditProfileModalProps {
  currentUser: UserProfile;
  onUpdate: (name: string, avatar: string) => void;
  onClose: () => void;
}

const EditProfileModal: React.FC<EditProfileModalProps> = ({ currentUser, onUpdate, onClose }) => {
  const [name, setName] = useState(currentUser.name);
  // Find the full avatar config object based on the emoji string
  const initialAvatarConfig = AVATARS.find(a => a.emoji === currentUser.avatar) || AVATARS[0];
  const [selectedAvatar, setSelectedAvatar] = useState(initialAvatarConfig);

  const previewTheme = THEME_COLORS[selectedAvatar.color];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onUpdate(name.trim(), selectedAvatar.emoji);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-sm shadow-2xl relative overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-800/50">
           <h3 className="font-bold text-lg text-white flex items-center gap-2">
             <User className="w-5 h-5 text-slate-400" />
             Edit Profile
           </h3>
           <button 
             onClick={onClose} 
             className="p-1 hover:bg-slate-700 rounded-full text-slate-400 hover:text-white transition-colors"
           >
             <X className="w-5 h-5" />
           </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          
          {/* Avatar Selection */}
          <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
                Avatar & Theme
              </label>
              <div className="grid grid-cols-6 gap-2">
                {AVATARS.map((config) => {
                  const isSelected = selectedAvatar.emoji === config.emoji;
                  const theme = THEME_COLORS[config.color];
                  return (
                    <button
                      key={config.emoji}
                      type="button"
                      onClick={() => setSelectedAvatar(config)}
                      className={`
                        aspect-square flex items-center justify-center text-2xl rounded-lg transition-all
                        ${isSelected
                          ? `${theme.subtleBg} ${theme.border} ring-1 ${theme.ring} scale-110 shadow-lg z-10` 
                          : 'bg-slate-800 border border-slate-700 hover:bg-slate-700 opacity-70 hover:opacity-100'
                        }
                      `}
                    >
                      {config.emoji}
                    </button>
                  );
                })}
              </div>
          </div>

          {/* Name Input */}
          <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                Display Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                className={`w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none transition-all placeholder-slate-600 focus:ring-1`}
                style={{ 
                    '--tw-ring-color': previewTheme.chart,
                    borderColor: name ? undefined : '' 
                } as React.CSSProperties}
              />
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-3 px-4 rounded-xl font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!name.trim()}
                className={`
                  flex-1 py-3 px-4 rounded-xl text-white font-semibold transition-all flex items-center justify-center gap-2
                  ${previewTheme.bg} ${previewTheme.bgHover} ${previewTheme.shadow}
                  disabled:opacity-50 disabled:cursor-not-allowed
                `}
              >
                <Save className="w-4 h-4" />
                Save Changes
              </button>
            </div>
        </form>
      </div>
    </div>
  );
};

export default EditProfileModal;