import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getFastingTip = async (
  hoursFasted: number,
  targetHours: number,
  mood: string
): Promise<string> => {
  try {
    const prompt = `
      You are an encouraging and knowledgeable intermittent fasting coach.
      The user is currently ${hoursFasted.toFixed(1)} hours into a ${targetHours}-hour fast.
      They are feeling: ${mood}.

      Provide a short, motivating tip (max 2 sentences).
      If relevant, mention the biological stage they might be in (e.g., blood sugar stabilizing, ketosis, autophagy) based on the hours fasted.
      Keep the tone empathetic but disciplined.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Keep going, you're doing great!";
  } catch (error) {
    console.error("Error fetching tip:", error);
    return "Stay hydrated and listen to your body. You've got this!";
  }
};

export const getMealAdvice = async (
  protocol: string
): Promise<string> => {
  try {
    const prompt = `
      The user is about to break their fast. They are following the ${protocol} protocol.
      Suggest 3 general healthy food ideas to break the fast gently and maximize benefits.
      Format as a concise bulleted list.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Start with lean protein and veggies.";
  } catch (error) {
    console.error("Error fetching meal advice:", error);
    return "Focus on whole foods, protein, and healthy fats.";
  }
};

export const askCoach = async (
  question: string,
  hoursFasted: number,
  targetHours: number,
  protocol: string
): Promise<string> => {
  try {
    const prompt = `
      You are an expert intermittent fasting coach.
      Context:
      - Protocol: ${protocol}
      - Progress: ${hoursFasted.toFixed(1)} / ${targetHours} hours
      
      User Question: "${question}"
      
      Answer concisely (max 3 sentences). Be scientific but accessible. Focus on health benefits and motivation.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "I couldn't process that right now, but keep hydrating!";
  } catch (error) {
    console.error("Error asking coach:", error);
    return "I'm having trouble connecting right now. Try again later.";
  }
};
