export interface FastingProtocol {
  id: string;
  name: string;
  fastingHours: number;
  eatingHours: number;
  description: string;
  detailedInfo?: {
    whatIsIt: string;
    whoIsItFor: string;
    pros: string[];
    cons: string[];
  };
  isCustom?: boolean;
}

export interface FastingSession {
  id: string;
  startTime: number; // Timestamp
  endTime: number | null; // Timestamp, null if active
  targetDurationHours: number;
  protocolName: string;
  mood?: string; // Optional mood logged at end
}

export interface UserProfile {
  id: string;
  name: string;
  email?: string;
  authProvider: 'local' | 'email' | 'google' | 'apple';
  avatar: string; // Emoji
  createdAt: number;
}

export interface SyncOperation {
  id: string;
  type: 'SESSION' | 'JOURNAL';
  timestamp: number;
  dataSummary?: string;
}

export enum AppState {
  IDLE = 'IDLE',
  FASTING = 'FASTING',
  EATING = 'EATING', // Post-fast, pre-next-fast
}

export const PROTOCOLS: FastingProtocol[] = [
  { 
    id: '13:11', 
    name: 'Circadian Rhythm (13:11)', 
    fastingHours: 13, 
    eatingHours: 11, 
    description: 'Best for beginners. Aligns with natural body clock.',
    detailedInfo: {
      whatIsIt: 'A gentle fasting window that mimics the natural day/night cycle. You simply stop eating after dinner and delay breakfast slightly.',
      whoIsItFor: 'Absolute beginners or those looking to improve sleep and digestion without stress.',
      pros: ['Easy to stick to', 'Improves sleep quality', 'Better digestion', 'Low stress on the body'],
      cons: ['Weight loss is slower', 'Less autophagy benefits compared to longer fasts']
    }
  },
  { 
    id: '16:8', 
    name: 'Leangains (16:8)', 
    fastingHours: 16, 
    eatingHours: 8, 
    description: 'The most popular method. Skip breakfast or dinner.',
    detailedInfo: {
      whatIsIt: 'The gold standard of intermittent fasting. You fast for 16 hours and eat all your meals within an 8-hour window.',
      whoIsItFor: 'Most people looking for fat loss, maintenance, or simplicity.',
      pros: ['Convenient for social life', 'Effective for fat loss', 'Improves insulin sensitivity', 'Simple rules'],
      cons: ['Can feel hungry in the mornings initially', 'Requires meal planning to hit nutrient goals']
    }
  },
  { 
    id: '18:6', 
    name: 'Classic (18:6)', 
    fastingHours: 18, 
    eatingHours: 6, 
    description: 'For experienced fasters wanting more autophagy.',
    detailedInfo: {
      whatIsIt: 'A step up from 16:8, tightening the eating window to just 6 hours.',
      whoIsItFor: 'Intermediate fasters who have plateaued on 16:8 or want deeper health benefits.',
      pros: ['Higher levels of autophagy', 'Greater fat burning', 'Less time spent cooking/eating'],
      cons: ['Harder to fit all calories in', 'Can be socially restrictive for dinners']
    }
  },
  { 
    id: '20:4', 
    name: 'Warrior Diet (20:4)', 
    fastingHours: 20, 
    eatingHours: 4, 
    description: 'Small eating window, high intensity.',
    detailedInfo: {
      whatIsIt: 'Involves fasting for 20 hours and eating one large meal (and maybe a snack) within 4 hours.',
      whoIsItFor: 'Advanced users, busy professionals, or those who prefer big meals.',
      pros: ['Excellent for mental clarity', 'Significant fat loss', 'Simplifies the day'],
      cons: ['Risk of binge eating during the window', 'Nutrient deficiency risk if not careful', 'Potential energy dips']
    }
  },
  { 
    id: '23:1', 
    name: 'OMAD (23:1)', 
    fastingHours: 23, 
    eatingHours: 1, 
    description: 'One Meal A Day. Advanced users only.',
    detailedInfo: {
      whatIsIt: 'One Meal A Day. You fast for 23 hours and eat your daily calories in a single 1-hour sitting.',
      whoIsItFor: 'Veterans of fasting seeking maximum weight loss or simplicity.',
      pros: ['Rapid weight loss', 'Extreme time saving', 'No meal prep stress'],
      cons: ['Digestion issues from large meals', 'Hard to eat enough protein', 'Not recommended for women with hormone imbalances']
    }
  },
  {
    id: '24h',
    name: '24-Hour Fast',
    fastingHours: 24,
    eatingHours: 0,
    description: 'A full day reset for gut rest.',
    detailedInfo: {
      whatIsIt: 'Fasting from dinner to dinner (or breakfast to breakfast). A full 24-hour break from food.',
      whoIsItFor: 'Those looking to break a plateau or reset their gut health 1-2 times a week.',
      pros: ['Great for gut microbiome', 'Teaches discipline', 'Significant calorie deficit'],
      cons: ['Hunger waves can be intense', 'Potential sleep disruption']
    }
  },
  {
    id: '36h',
    name: '36-Hour Monk Fast',
    fastingHours: 36,
    eatingHours: 0,
    description: 'Deep ketosis and high autophagy.',
    detailedInfo: {
      whatIsIt: 'A 36-hour continuous fast. Usually stop eating dinner on Day 1 and eat breakfast on Day 3.',
      whoIsItFor: 'Experienced fasters seeking deep cellular repair and ketosis.',
      pros: ['Deep ketosis', 'High autophagy (cellular cleaning)', 'Reduces inflammation'],
      cons: ['Requires electrolyte management', 'Socially difficult', 'Energy fluctuations']
    }
  },
  {
    id: '48h',
    name: '48-Hour Reset',
    fastingHours: 48,
    eatingHours: 0,
    description: 'Advanced cellular repair and dopamine reset.',
    detailedInfo: {
      whatIsIt: 'Two full days without food. A serious challenge for metabolic reset.',
      whoIsItFor: 'Advanced fasters only. Good for immune system reset.',
      pros: ['Massive boost in Human Growth Hormone', 'Immune system regeneration', 'Breaks unhealthy food addictions'],
      cons: ['Risk of refeeding syndrome (rare but possible)', 'Muscle loss risk if sedentary', 'High mental difficulty']
    }
  },
  {
    id: 'custom',
    name: 'Custom Fast',
    fastingHours: 12, // Default
    eatingHours: 12,
    description: 'Set your own fasting goal.',
    isCustom: true,
    detailedInfo: {
        whatIsIt: 'A flexible fasting timer where you control the duration.',
        whoIsItFor: 'Anyone whose schedule doesn\'t fit standard protocols.',
        pros: ['Complete flexibility', 'Adaptable to any lifestyle'],
        cons: ['Requires self-discipline', 'Lack of structured guidance']
    }
  }
];

// --- Theme & Avatar Config ---

export type ThemeColor = 'blue' | 'indigo' | 'emerald' | 'orange' | 'amber' | 'violet' | 'fuchsia' | 'rose' | 'cyan' | 'teal' | 'lime' | 'red';

export interface AvatarConfig {
  emoji: string;
  color: ThemeColor;
}

export const AVATARS: AvatarConfig[] = [
  { emoji: '🦁', color: 'amber' },
  { emoji: '🦊', color: 'orange' },
  { emoji: '🐼', color: 'teal' },
  { emoji: '🐨', color: 'indigo' },
  { emoji: '🐯', color: 'rose' },
  { emoji: '🐸', color: 'lime' },
  { emoji: '🐙', color: 'violet' },
  { emoji: '🦄', color: 'fuchsia' },
  { emoji: '🐲', color: 'red' },
  { emoji: '🦉', color: 'cyan' },
  { emoji: '🦋', color: 'blue' },
  { emoji: '🌵', color: 'emerald' },
];

export interface ThemeClasses {
  primary: string; // text-color-500
  bg: string; // bg-color-600
  bgHover: string; // hover:bg-color-500
  border: string; // border-color-500
  ring: string; // ring-color-500
  gradient: string; // from-color-600 to-color-X
  shadow: string; // shadow-color-900/20
  subtleBg: string; // bg-color-500/10
  subtleText: string; // text-color-400
  glow: string; // shadow-color-500/50
  chart: string; // hex code
}

export const THEME_COLORS: Record<ThemeColor, ThemeClasses> = {
  blue: { primary: 'text-blue-500', bg: 'bg-blue-600', bgHover: 'hover:bg-blue-500', border: 'border-blue-500', ring: 'ring-blue-500', gradient: 'from-blue-600 to-indigo-600', shadow: 'shadow-blue-900/30', subtleBg: 'bg-blue-500/10', subtleText: 'text-blue-400', glow: 'shadow-blue-500/50', chart: '#3b82f6' },
  indigo: { primary: 'text-indigo-500', bg: 'bg-indigo-600', bgHover: 'hover:bg-indigo-500', border: 'border-indigo-500', ring: 'ring-indigo-500', gradient: 'from-indigo-600 to-violet-600', shadow: 'shadow-indigo-900/30', subtleBg: 'bg-indigo-500/10', subtleText: 'text-indigo-400', glow: 'shadow-indigo-500/50', chart: '#6366f1' },
  emerald: { primary: 'text-emerald-500', bg: 'bg-emerald-600', bgHover: 'hover:bg-emerald-500', border: 'border-emerald-500', ring: 'ring-emerald-500', gradient: 'from-emerald-600 to-teal-600', shadow: 'shadow-emerald-900/30', subtleBg: 'bg-emerald-500/10', subtleText: 'text-emerald-400', glow: 'shadow-emerald-500/50', chart: '#10b981' },
  orange: { primary: 'text-orange-500', bg: 'bg-orange-600', bgHover: 'hover:bg-orange-500', border: 'border-orange-500', ring: 'ring-orange-500', gradient: 'from-orange-600 to-red-600', shadow: 'shadow-orange-900/30', subtleBg: 'bg-orange-500/10', subtleText: 'text-orange-400', glow: 'shadow-orange-500/50', chart: '#f97316' },
  amber: { primary: 'text-amber-500', bg: 'bg-amber-600', bgHover: 'hover:bg-amber-500', border: 'border-amber-500', ring: 'ring-amber-500', gradient: 'from-amber-600 to-orange-600', shadow: 'shadow-amber-900/30', subtleBg: 'bg-amber-500/10', subtleText: 'text-amber-400', glow: 'shadow-amber-500/50', chart: '#f59e0b' },
  violet: { primary: 'text-violet-500', bg: 'bg-violet-600', bgHover: 'hover:bg-violet-500', border: 'border-violet-500', ring: 'ring-violet-500', gradient: 'from-violet-600 to-fuchsia-600', shadow: 'shadow-violet-900/30', subtleBg: 'bg-violet-500/10', subtleText: 'text-violet-400', glow: 'shadow-violet-500/50', chart: '#8b5cf6' },
  fuchsia: { primary: 'text-fuchsia-500', bg: 'bg-fuchsia-600', bgHover: 'hover:bg-fuchsia-500', border: 'border-fuchsia-500', ring: 'ring-fuchsia-500', gradient: 'from-fuchsia-600 to-pink-600', shadow: 'shadow-fuchsia-900/30', subtleBg: 'bg-fuchsia-500/10', subtleText: 'text-fuchsia-400', glow: 'shadow-fuchsia-500/50', chart: '#d946ef' },
  rose: { primary: 'text-rose-500', bg: 'bg-rose-600', bgHover: 'hover:bg-rose-500', border: 'border-rose-500', ring: 'ring-rose-500', gradient: 'from-rose-600 to-red-600', shadow: 'shadow-rose-900/30', subtleBg: 'bg-rose-500/10', subtleText: 'text-rose-400', glow: 'shadow-rose-500/50', chart: '#f43f5e' },
  cyan: { primary: 'text-cyan-500', bg: 'bg-cyan-600', bgHover: 'hover:bg-cyan-500', border: 'border-cyan-500', ring: 'ring-cyan-500', gradient: 'from-cyan-600 to-blue-600', shadow: 'shadow-cyan-900/30', subtleBg: 'bg-cyan-500/10', subtleText: 'text-cyan-400', glow: 'shadow-cyan-500/50', chart: '#06b6d4' },
  teal: { primary: 'text-teal-500', bg: 'bg-teal-600', bgHover: 'hover:bg-teal-500', border: 'border-teal-500', ring: 'ring-teal-500', gradient: 'from-teal-600 to-emerald-600', shadow: 'shadow-teal-900/30', subtleBg: 'bg-teal-500/10', subtleText: 'text-teal-400', glow: 'shadow-teal-500/50', chart: '#14b8a6' },
  lime: { primary: 'text-lime-500', bg: 'bg-lime-600', bgHover: 'hover:bg-lime-500', border: 'border-lime-500', ring: 'ring-lime-500', gradient: 'from-lime-600 to-green-600', shadow: 'shadow-lime-900/30', subtleBg: 'bg-lime-500/10', subtleText: 'text-lime-400', glow: 'shadow-lime-500/50', chart: '#84cc16' },
  red: { primary: 'text-red-500', bg: 'bg-red-600', bgHover: 'hover:bg-red-500', border: 'border-red-500', ring: 'ring-red-500', gradient: 'from-red-600 to-orange-600', shadow: 'shadow-red-900/30', subtleBg: 'bg-red-500/10', subtleText: 'text-red-400', glow: 'shadow-red-500/50', chart: '#ef4444' },
};
