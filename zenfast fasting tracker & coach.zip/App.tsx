import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Play, Square, Edit2, Calendar, ChevronDown, Utensils, Info, Flame, Bell, X, Clock, BarChart2, Settings, LogOut, User as UserIcon, Trophy, Target, Cloud, CloudOff, RefreshCw, CheckCircle2 } from 'lucide-react';
import TimerRing from './components/TimerRing';
import ProtocolSelector from './components/ProtocolSelector';
import FastingCoach from './components/FastingCoach';
import CalendarDashboard from './components/CalendarDashboard';
import AuthScreen from './components/AuthScreen';
import Onboarding from './components/Onboarding';
import StatsWidgets from './components/StatsWidgets';
import EditProfileModal from './components/EditProfileModal';
import { useTimerWorker } from './hooks/useTimerWorker';
import { FastingProtocol, PROTOCOLS, FastingSession, AppState, UserProfile, AVATARS, THEME_COLORS, ThemeClasses, SyncOperation } from './types';
import { getMealAdvice } from './services/geminiService';

const App: React.FC = () => {
  // --- Auth & Profile State ---
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);

  // --- App State ---
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [selectedProtocol, setSelectedProtocol] = useState<FastingProtocol>(PROTOCOLS[1]);
  const [startTime, setStartTime] = useState<number | null>(null);
  
  // Replace direct interval state with Web Worker hook
  const elapsedSeconds = useTimerWorker(startTime, appState === AppState.FASTING);
  
  const [history, setHistory] = useState<FastingSession[]>([]);
  const [showDashboard, setShowDashboard] = useState(false);
  const [mealAdvice, setMealAdvice] = useState<string | null>(null);
  const [showAdviceModal, setShowAdviceModal] = useState(false);
  const [streak, setStreak] = useState(0);
  
  // Streak Goal State
  const [streakGoal, setStreakGoal] = useState(7);
  const [showStreakGoalModal, setShowStreakGoalModal] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  
  // Journal State
  const [journal, setJournal] = useState<Record<string, string>>({});

  // Reminder State
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [reminderTime, setReminderTime] = useState("20:00");
  const [isReminderEnabled, setIsReminderEnabled] = useState(false);
  const lastNotificationRef = useRef<string>("");

  // Confirmation State
  const [showEndConfirm, setShowEndConfirm] = useState(false);

  // Change Protocol State
  const [showProtocolModal, setShowProtocolModal] = useState(false);

  // --- Offline Sync State ---
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncQueue, setSyncQueue] = useState<SyncOperation[]>([]);
  const [lastSyncTime, setLastSyncTime] = useState<number | null>(null);

  // --- Helpers for Storage Namespacing ---
  const getKey = (key: string, userId: string = currentUser?.id || 'default') => `user_${userId}_${key}`;

  // --- Theme derivation ---
  const getCurrentTheme = (): ThemeClasses => {
    if (!currentUser) return THEME_COLORS['blue']; // Default fallback
    const config = AVATARS.find(a => a.emoji === currentUser.avatar);
    return config ? THEME_COLORS[config.color] : THEME_COLORS['blue'];
  };

  const theme = getCurrentTheme();

  // --- Initialization & Auth Effects ---

  // 1. Load Profiles
  useEffect(() => {
    const savedProfiles = localStorage.getItem('zenfast_profiles');
    const savedActiveId = localStorage.getItem('zenfast_active_id');
    
    let loadedProfiles: UserProfile[] = [];
    if (savedProfiles) {
      loadedProfiles = JSON.parse(savedProfiles);
      setProfiles(loadedProfiles);
    }

    // Migration Check: If no profiles but data exists, create a default profile
    if (loadedProfiles.length === 0) {
      const legacyHistory = localStorage.getItem('fastingHistory');
      if (legacyHistory) {
        // Create default profile
        const defaultProfile: UserProfile = {
          id: crypto.randomUUID(),
          name: 'Default User',
          authProvider: 'local',
          avatar: '👤',
          createdAt: Date.now()
        };
        
        // Migrate Data
        const keysToMigrate = ['currentSession', 'fastingHistory', 'fastingStreak', 'lastFastDate', 'fastingJournal', 'reminderTime', 'isReminderEnabled'];
        keysToMigrate.forEach(key => {
          const val = localStorage.getItem(key);
          if (val) {
            localStorage.setItem(`user_${defaultProfile.id}_${key}`, val);
            localStorage.removeItem(key); // Cleanup legacy
          }
        });

        // Mark migrated user as onboarded
        localStorage.setItem(`user_${defaultProfile.id}_hasOnboarded`, 'true');

        // Save new profile structure
        loadedProfiles = [defaultProfile];
        setProfiles(loadedProfiles);
        localStorage.setItem('zenfast_profiles', JSON.stringify(loadedProfiles));
        
        // Auto login
        handleLogin(defaultProfile);
        return; 
      }
    }

    // Auto login if session persisted
    if (savedActiveId && loadedProfiles.length > 0) {
      const active = loadedProfiles.find(p => p.id === savedActiveId);
      if (active) {
        handleLogin(active);
      }
    }
  }, []);

  // 2. Load User Data when currentUser changes
  useEffect(() => {
    if (!currentUser) return;

    const userId = currentUser.id;
    
    const savedSession = localStorage.getItem(getKey('currentSession', userId));
    const savedHistory = localStorage.getItem(getKey('fastingHistory', userId));
    const savedStreak = parseInt(localStorage.getItem(getKey('fastingStreak', userId)) || '0', 10);
    const savedStreakGoal = parseInt(localStorage.getItem(getKey('streakGoal', userId)) || '7', 10);
    const lastFastDate = localStorage.getItem(getKey('lastFastDate', userId));
    const savedJournal = localStorage.getItem(getKey('fastingJournal', userId));
    const savedSyncQueue = localStorage.getItem(getKey('syncQueue', userId));

    // Reminder Settings
    const savedReminderTime = localStorage.getItem(getKey('reminderTime', userId)) || "20:00";
    const savedReminderEnabled = localStorage.getItem(getKey('isReminderEnabled', userId)) === 'true';
    setReminderTime(savedReminderTime);
    setIsReminderEnabled(savedReminderEnabled);
    
    let loadedHistory = [];
    if (savedHistory) {
        loadedHistory = JSON.parse(savedHistory);
        setHistory(loadedHistory);
    } else {
        setHistory([]);
    }

    if (savedJournal) setJournal(JSON.parse(savedJournal));
    else setJournal({});
    
    if (savedSyncQueue) setSyncQueue(JSON.parse(savedSyncQueue));

    // Set Streak Goal
    setStreakGoal(savedStreakGoal);

    // Check streak validity
    if (lastFastDate) {
      const lastDate = new Date(lastFastDate);
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      lastDate.setHours(0, 0, 0, 0);
      yesterday.setHours(0, 0, 0, 0);

      if (lastDate < yesterday) {
        setStreak(0);
      } else {
        setStreak(savedStreak);
      }
    } else {
      setStreak(savedStreak);
    }

    // Restore Session
    if (savedSession) {
      const session = JSON.parse(savedSession);
      if (session.endTime === null) {
        // Try finding by name first, fallback to hours match if renamed
        const protocol = PROTOCOLS.find(p => p.name === session.protocolName) || 
                         PROTOCOLS.find(p => p.fastingHours === session.targetDurationHours) || 
                         PROTOCOLS[1];
        
        setSelectedProtocol(protocol);
        setStartTime(session.startTime);
        setAppState(AppState.FASTING);
      } else {
        setAppState(AppState.IDLE);
        setStartTime(null);
      }
    } else {
      setAppState(AppState.IDLE);
      setStartTime(null);
    }

    // Onboarding Check
    const hasOnboarded = localStorage.getItem(getKey('hasOnboarded', userId));
    // If they have history but no onboarded flag, assume they are an old user and skip onboarding
    if (hasOnboarded === 'true' || loadedHistory.length > 0) {
        setShowOnboarding(false);
        if (!hasOnboarded) {
             localStorage.setItem(getKey('hasOnboarded', userId), 'true');
        }
    } else {
        setShowOnboarding(true);
    }

  }, [currentUser]);

  // --- Network & Sync Listeners ---
  useEffect(() => {
    const handleOnline = () => {
        setIsOnline(true);
        processSyncQueue();
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Process queue when queue changes and we are online
  useEffect(() => {
    if (isOnline && syncQueue.length > 0 && !isSyncing) {
        // Debounce sync slightly to batch UI updates
        const timer = setTimeout(() => processSyncQueue(), 1000);
        return () => clearTimeout(timer);
    }
  }, [isOnline, syncQueue]);

  // Reminder Check
  useEffect(() => {
    if (!currentUser) return;
    const checkReminder = () => {
        if (!isReminderEnabled) return;
        const now = new Date();
        const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

        if (currentTime === reminderTime) {
            const todayKey = now.toDateString() + currentTime + currentUser.id;
            if (lastNotificationRef.current !== todayKey) {
                if (Notification.permission === 'granted') {
                    new Notification(`Hi ${currentUser.name}!`, {
                        body: "It's time to start your fasting window.",
                        icon: "/favicon.ico"
                    });
                }
                lastNotificationRef.current = todayKey;
            }
        }
    };
    const interval = setInterval(checkReminder, 5000);
    return () => clearInterval(interval);
  }, [reminderTime, isReminderEnabled, currentUser]);

  // --- Auth Actions ---

  const handleLogin = (profile: UserProfile) => {
    setCurrentUser(profile);
    localStorage.setItem('zenfast_active_id', profile.id);
  };

  const handleCreateProfile = (name: string, avatar: string, email?: string, provider: 'email'|'google'|'apple'|'local' = 'local') => {
    const newProfile: UserProfile = {
      id: crypto.randomUUID(),
      name,
      email,
      authProvider: provider,
      avatar,
      createdAt: Date.now()
    };
    const updatedProfiles = [...profiles, newProfile];
    setProfiles(updatedProfiles);
    localStorage.setItem('zenfast_profiles', JSON.stringify(updatedProfiles));
    handleLogin(newProfile);
  };

  const handleUpdateProfile = (name: string, avatar: string) => {
    if (!currentUser) return;
    const updatedUser: UserProfile = { ...currentUser, name, avatar };
    
    const updatedProfiles = profiles.map(p => p.id === currentUser.id ? updatedUser : p);
    setProfiles(updatedProfiles);
    setCurrentUser(updatedUser);
    localStorage.setItem('zenfast_profiles', JSON.stringify(updatedProfiles));
    
    setShowEditProfileModal(false);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('zenfast_active_id');
    setAppState(AppState.IDLE);
    setStartTime(null);
    setShowProfileMenu(false);
  };

  const handleCompleteOnboarding = () => {
      if (!currentUser) return;
      localStorage.setItem(getKey('hasOnboarded', currentUser.id), 'true');
      setShowOnboarding(false);
  };

  // --- Sync Logic ---

  const addToSyncQueue = (op: SyncOperation) => {
      if (!currentUser) return;
      const newQueue = [...syncQueue, op];
      setSyncQueue(newQueue);
      localStorage.setItem(getKey('syncQueue', currentUser.id), JSON.stringify(newQueue));
  };

  const processSyncQueue = async () => {
      if (syncQueue.length === 0 || !currentUser) return;
      
      setIsSyncing(true);
      
      // Simulate network request delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Clear queue
      setSyncQueue([]);
      localStorage.removeItem(getKey('syncQueue', currentUser.id));
      
      setIsSyncing(false);
      setLastSyncTime(Date.now());
  };

  // --- App Actions ---

  const startFast = () => {
    if (!currentUser) return;
    if ("Notification" in window && Notification.permission !== "granted") {
        Notification.requestPermission();
    }
    const start = Date.now();
    setStartTime(start);
    setAppState(AppState.FASTING);
    
    const newSession: FastingSession = {
      id: crypto.randomUUID(),
      startTime: start,
      endTime: null,
      targetDurationHours: selectedProtocol.fastingHours,
      protocolName: selectedProtocol.name
    };
    
    localStorage.setItem(getKey('currentSession'), JSON.stringify(newSession));
  };

  const endFast = async () => {
    if (!startTime || !currentUser) return;

    const end = Date.now();
    const durationHours = (end - startTime) / (1000 * 60 * 60);
    
    const session: FastingSession = {
      id: crypto.randomUUID(),
      startTime: startTime,
      endTime: end,
      targetDurationHours: selectedProtocol.fastingHours,
      protocolName: selectedProtocol.name
    };

    const newHistory = [session, ...history];
    setHistory(newHistory);
    localStorage.setItem(getKey('fastingHistory'), JSON.stringify(newHistory));
    localStorage.removeItem(getKey('currentSession'));

    // Update Streak
    const today = new Date().toDateString();
    const yesterday = new Date(Date.now() - 86400000).toDateString();
    const lastFastDate = localStorage.getItem(getKey('lastFastDate'));
    const storedStreak = parseInt(localStorage.getItem(getKey('fastingStreak')) || '0', 10);
    
    let newStreak = (lastFastDate === yesterday) ? storedStreak + 1 : (lastFastDate === today ? storedStreak : 1);
    
    setStreak(newStreak);
    localStorage.setItem(getKey('fastingStreak'), newStreak.toString());
    localStorage.setItem(getKey('lastFastDate'), today);

    // Sync Queue logic
    if (!isOnline) {
        addToSyncQueue({
            id: session.id,
            type: 'SESSION',
            timestamp: Date.now(),
            dataSummary: `${session.targetDurationHours}h Fast`
        });
    }

    // Check Goal Celebration
    if (newStreak === streakGoal && streakGoal > 0) {
        setShowCelebration(true);
    }

    setAppState(AppState.IDLE);
    setStartTime(null);
    // elapsedSeconds reset is handled by hook when startTime becomes null

    if (durationHours > 12 && !showCelebration && isOnline) { // Only fetch advice if online
      setMealAdvice("Loading advice...");
      setShowAdviceModal(true);
      const advice = await getMealAdvice(selectedProtocol.name);
      setMealAdvice(advice);
    }
  };

  const editStartTime = () => {
    if (!startTime || !currentUser) return;
    const offsetHours = prompt("Adjust start time by hours (e.g. -1 for 1 hour ago):", "0");
    if (offsetHours && !isNaN(parseFloat(offsetHours))) {
      const newStart = startTime + (parseFloat(offsetHours) * 3600 * 1000);
      setStartTime(newStart);
      const session = JSON.parse(localStorage.getItem(getKey('currentSession')) || '{}');
      if (session.id) {
        session.startTime = newStart;
        localStorage.setItem(getKey('currentSession'), JSON.stringify(session));
      }
    }
  };

  const handleChangeProtocolDuringFast = (p: FastingProtocol) => {
    if (!currentUser) return;
    setSelectedProtocol(p);
    const session = JSON.parse(localStorage.getItem(getKey('currentSession')) || '{}');
    if (session.id) {
        session.targetDurationHours = p.fastingHours;
        session.protocolName = p.name;
        localStorage.setItem(getKey('currentSession'), JSON.stringify(session));
    }
    setShowProtocolModal(false);
  };

  const handleUpdateJournal = (date: string, text: string) => {
    if (!currentUser) return;
    const updatedJournal = { ...journal, [date]: text };
    setJournal(updatedJournal);
    localStorage.setItem(getKey('fastingJournal'), JSON.stringify(updatedJournal));

    if (!isOnline) {
        addToSyncQueue({
            id: date,
            type: 'JOURNAL',
            timestamp: Date.now(),
            dataSummary: 'Journal Entry'
        });
    }
  };

  const toggleReminder = async () => {
    if (!currentUser) return;
    if (!isReminderEnabled) {
        const permission = await Notification.requestPermission();
        if (permission !== 'granted') {
            alert('Please enable notifications.');
            return;
        }
    }
    const newState = !isReminderEnabled;
    setIsReminderEnabled(newState);
    localStorage.setItem(getKey('isReminderEnabled'), String(newState));
  };

  const handleTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!currentUser) return;
    const time = e.target.value;
    setReminderTime(time);
    localStorage.setItem(getKey('reminderTime'), time);
  };

  const handleGetMealAdvice = async () => {
    if (!isOnline) {
        alert("You need to be online to get AI advice.");
        return;
    }
    setMealAdvice("Loading advice...");
    setShowAdviceModal(true);
    const advice = await getMealAdvice(selectedProtocol.name);
    setMealAdvice(advice);
  };
  
  const handleUpdateStreakGoal = (newGoal: number) => {
      if (!currentUser) return;
      setStreakGoal(newGoal);
      localStorage.setItem(getKey('streakGoal'), newGoal.toString());
      setShowStreakGoalModal(false);
  };

  // --- Derived Values ---
  const progress = !startTime ? 0 : Math.min(((elapsedSeconds) / (selectedProtocol.fastingHours * 3600)) * 100, 100);
  const hoursFasted = elapsedSeconds / 3600;
  const isTargetReached = hoursFasted >= selectedProtocol.fastingHours;
  const formatTime = (totalSeconds: number) => {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (!currentUser) {
    return <AuthScreen profiles={profiles} onLogin={handleLogin} onCreateProfile={handleCreateProfile} />;
  }

  return (
    <div className="min-h-screen bg-[#0f172a] text-white flex flex-col items-center pb-12 relative selection:bg-blue-500/30">
      
      {/* Header */}
      <header className="w-full max-w-md p-6 flex justify-between items-center z-10 relative">
        <div className="relative">
          <button 
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="flex items-center gap-2 hover:bg-slate-800/50 p-1.5 pr-3 rounded-xl transition-all border border-transparent hover:border-slate-700/50"
          >
              <div className={`w-9 h-9 rounded-lg bg-gradient-to-tr ${theme.gradient} flex items-center justify-center text-lg ${theme.shadow} border border-white/10`}>
                  {currentUser.avatar}
              </div>
              <div className="flex flex-col items-start">
                  <span className="text-xs text-slate-400 font-medium leading-none mb-0.5">Hello,</span>
                  <span className="text-sm font-bold text-white leading-none">{currentUser.name}</span>
              </div>
              <ChevronDown className={`w-3 h-3 text-slate-500 transition-transform ${showProfileMenu ? 'rotate-180' : ''}`} />
          </button>

          {/* Profile Dropdown */}
          {showProfileMenu && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowProfileMenu(false)} />
              <div className="absolute top-full left-0 mt-2 w-48 bg-slate-900 border border-slate-700 rounded-xl shadow-xl z-20 py-1 animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="px-4 py-2 border-b border-slate-800">
                    <div className="text-xs text-slate-500">Signed in as</div>
                    <div className="text-sm text-white truncate">{currentUser.email || currentUser.name}</div>
                </div>
                <button 
                    onClick={() => { setShowProfileMenu(false); setShowEditProfileModal(true); }}
                    className="w-full text-left px-4 py-3 hover:bg-slate-800 flex items-center gap-2 text-sm text-slate-300 font-medium border-b border-slate-800"
                >
                  <Settings className="w-4 h-4" />
                  Edit Profile
                </button>
                <button onClick={handleLogout} className="w-full text-left px-4 py-3 text-red-400 hover:bg-slate-800 flex items-center gap-2 text-sm font-medium rounded-b-xl">
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            </>
          )}
        </div>

        <div className="flex items-center gap-3">
          {/* Sync Status Indicator */}
          <div 
             className={`flex items-center justify-center w-8 h-8 rounded-full border backdrop-blur-sm transition-all ${isSyncing ? `bg-slate-800 ${theme.border} border-opacity-50` : 'bg-slate-800/60 border-slate-700/60'}`} 
             title={!isOnline ? `${syncQueue.length} changes queued` : isSyncing ? "Syncing..." : "Online & Synced"}
          >
             {isSyncing ? (
                 <RefreshCw className={`w-4 h-4 ${theme.primary} animate-spin`} />
             ) : !isOnline ? (
                 <div className="relative">
                    <CloudOff className="w-4 h-4 text-slate-500" />
                    {syncQueue.length > 0 && (
                        <span className="absolute -top-2 -right-2 flex h-4 w-4 items-center justify-center rounded-full bg-orange-500 border border-slate-900 text-[10px] font-bold text-white shadow-sm">
                            {syncQueue.length}
                        </span>
                    )}
                 </div>
             ) : (
                 <Cloud className="w-4 h-4 text-emerald-500" />
             )}
          </div>

          <button 
             onClick={() => setShowStreakGoalModal(true)}
             className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/60 border border-slate-700/60 rounded-full backdrop-blur-sm hover:bg-slate-700/80 transition-colors" 
             title="Current Streak / Goal"
          >
              <Flame className={`w-4 h-4 ${streak > 0 ? 'fill-orange-500 text-orange-500' : 'text-slate-600'}`} />
              <span className={`text-sm font-bold font-mono ${streak > 0 ? 'text-orange-100' : 'text-slate-500'}`}>
                {streak} <span className="text-slate-600 text-xs">/ {streakGoal}</span>
              </span>
          </button>

          <div className="flex bg-slate-800/60 rounded-full p-1 border border-slate-700/60 backdrop-blur-sm">
             <button 
                onClick={() => setShowReminderModal(true)}
                className="p-1.5 rounded-full hover:bg-slate-700 text-slate-400 hover:text-white transition-colors relative"
            >
                <Bell className="w-5 h-5" />
                {isReminderEnabled && (
                    <span className={`absolute top-1 right-1.5 block h-1.5 w-1.5 rounded-full ${theme.bg} ring-2 ring-slate-800`} />
                )}
            </button>
            <div className="w-px bg-slate-700/60 mx-1 my-1"></div>
            <button 
                onClick={() => setShowDashboard(true)}
                className="p-1.5 rounded-full hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
                <Calendar className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="w-full max-w-md px-6 flex flex-col items-center gap-8 flex-1">
        
        {/* State Indicator */}
        <div className="flex flex-col items-center gap-1 animate-fade-in">
             <span className={`text-sm font-medium tracking-widest uppercase ${appState === AppState.FASTING ? theme.primary : 'text-slate-400'}`}>
                {appState === AppState.FASTING ? 'Fasting Window' : 'Ready to Fast'}
             </span>
             {appState === AppState.FASTING ? (
                 <div className="flex items-center gap-2 text-slate-500 text-xs">
                     <span>Started {new Date(startTime!).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                     <span>•</span>
                     <span>Goal {new Date(startTime! + selectedProtocol.fastingHours * 3600000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                 </div>
             ) : (
                isReminderEnabled && (
                    <div className="flex items-center gap-1.5 text-slate-500 text-xs mt-1 bg-slate-800/50 px-3 py-1 rounded-full border border-slate-700/50">
                        <Clock className="w-3 h-3" />
                        <span>Reminder set for {reminderTime}</span>
                    </div>
                )
             )}
             {/* Offline Status Message */}
             {!isOnline && syncQueue.length > 0 && (
                 <div className="mt-2 flex items-center gap-1.5 px-3 py-1 bg-orange-500/10 border border-orange-500/20 rounded-full text-orange-400 text-xs animate-in fade-in slide-in-from-top-1">
                     <CloudOff className="w-3 h-3" />
                     <span>{syncQueue.length} changes queued for sync</span>
                 </div>
             )}
        </div>

        {/* Timer Ring */}
        <div className="relative">
            <TimerRing 
                progress={appState === AppState.FASTING ? progress : 100} 
                isFasting={appState === AppState.FASTING}
                size={280}
                theme={theme}
            >
                <div className="text-center">
                    {appState === AppState.FASTING ? (
                        <>
                            <div className="text-6xl font-bold tabular-nums tracking-tighter text-white mb-1">
                                {formatTime(elapsedSeconds)}
                            </div>
                            <div className="text-slate-400 font-medium">
                                {isTargetReached ? 'Target Reached!' : 'Time Fasted'}
                            </div>
                        </>
                    ) : (
                        <div className="text-center px-8">
                             <div className="text-4xl font-bold text-slate-200 mb-2">
                                {selectedProtocol.name}
                             </div>
                             <div className="text-slate-500 text-sm">
                                {selectedProtocol.fastingHours}h Fasting • {selectedProtocol.eatingHours}h Eating
                             </div>
                        </div>
                    )}
                </div>
            </TimerRing>

            {appState === AppState.FASTING && (
                 <button 
                    onClick={editStartTime}
                    className="absolute top-0 right-0 p-2 bg-slate-800/80 rounded-full text-slate-400 hover:text-white backdrop-blur-sm border border-slate-700"
                    title="Edit Start Time"
                 >
                     <Edit2 className="w-4 h-4" />
                 </button>
            )}
        </div>

        {/* Controls */}
        <div className="w-full flex flex-col gap-4">
            {appState === AppState.IDLE ? (
                <>
                    <button
                        onClick={startFast}
                        className={`w-full py-4 rounded-2xl bg-gradient-to-r ${theme.gradient} ${theme.bgHover} text-white font-bold text-lg ${theme.shadow} transform hover:scale-[1.02] transition-all flex items-center justify-center gap-3`}
                    >
                        <Play className="w-6 h-6 fill-current" />
                        Start Fasting
                    </button>
                    
                    <div className="w-full mt-4">
                        <ProtocolSelector 
                            selectedId={selectedProtocol.id} 
                            onSelect={setSelectedProtocol} 
                            theme={theme}
                        />
                    </div>

                    {history.length > 0 && (
                        <>
                            <div className="w-full">
                                <h3 className="text-slate-400 text-sm uppercase tracking-wider font-semibold mb-3">Stats Overview</h3>
                                <StatsWidgets history={history} streak={streak} theme={theme} />
                            </div>

                            <button
                                onClick={handleGetMealAdvice}
                                className={`w-full py-3 rounded-xl ${theme.subtleBg} hover:bg-slate-800 ${theme.subtleText} border ${theme.border} border-opacity-30 transition-all text-sm font-medium flex items-center justify-center gap-2`}
                            >
                                <Utensils className="w-4 h-4" />
                                Get Meal Advice
                            </button>
                        </>
                    )}
                </>
            ) : (
                <>
                    <div className="grid grid-cols-2 gap-4">
                        <button
                            onClick={() => setShowEndConfirm(true)}
                            className="w-full py-4 rounded-2xl bg-slate-800 border border-slate-700 hover:bg-slate-700 text-slate-200 font-bold text-lg transition-all flex items-center justify-center gap-2"
                        >
                            <Square className="w-5 h-5 fill-current" />
                            End Fast
                        </button>
                        
                        <button 
                            onClick={() => setShowProtocolModal(true)}
                            className="w-full py-4 rounded-2xl bg-slate-800/50 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/50 transition-all text-sm font-medium flex items-center justify-center gap-2"
                        >
                            <Edit2 className="w-5 h-5" />
                            Edit Goal
                        </button>
                    </div>

                    <div className="w-full mt-2">
                         <StatsWidgets history={history} streak={streak} theme={theme} />
                    </div>
                </>
            )}
        </div>

        {/* AI Coach Section */}
        {appState === AppState.FASTING && (
            <FastingCoach 
                hoursFasted={hoursFasted} 
                targetHours={selectedProtocol.fastingHours}
                protocolName={selectedProtocol.name}
                isFasting={appState === AppState.FASTING}
                theme={theme}
            />
        )}
      </main>

      {/* Onboarding Modal */}
      {showOnboarding && (
        <Onboarding 
            onComplete={handleCompleteOnboarding}
            selectedProtocolId={selectedProtocol.id}
            onSelectProtocol={setSelectedProtocol}
            theme={theme}
        />
      )}

      {/* Edit Profile Modal */}
      {showEditProfileModal && currentUser && (
        <EditProfileModal 
            currentUser={currentUser}
            onUpdate={handleUpdateProfile}
            onClose={() => setShowEditProfileModal(false)}
        />
      )}

      {/* Streak Goal Settings Modal */}
      {showStreakGoalModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-xs w-full shadow-2xl relative">
                <button onClick={() => setShowStreakGoalModal(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white">
                    <X className="w-5 h-5" />
                </button>
                <div className="flex items-center gap-3 mb-6">
                    <Target className={`w-6 h-6 ${theme.primary}`} />
                    <h3 className="font-bold text-lg text-white">Set Streak Goal</h3>
                </div>
                
                <p className="text-slate-400 text-sm mb-4">Choose a target to stay consistent. We'll celebrate when you reach it!</p>

                <div className="grid grid-cols-4 gap-2 mb-4">
                    {[3, 7, 14, 30].map(days => (
                        <button
                            key={days}
                            onClick={() => handleUpdateStreakGoal(days)}
                            className={`py-2 rounded-lg text-sm font-medium border transition-colors ${streakGoal === days ? `${theme.bg} text-white border-transparent` : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'}`}
                        >
                            {days}d
                        </button>
                    ))}
                </div>

                <div>
                    <label className="block text-xs text-slate-500 uppercase tracking-wider font-semibold mb-2">Custom Goal (Days)</label>
                    <div className="flex gap-2">
                        <input 
                            type="number" 
                            min="1"
                            value={streakGoal} 
                            onChange={(e) => setStreakGoal(parseInt(e.target.value) || 0)} 
                            className={`w-full bg-slate-800 border border-slate-600 text-white rounded-xl px-4 py-2 focus:outline-none focus:ring-1 ${theme.ring} focus:border-transparent`} 
                        />
                        <button 
                            onClick={() => handleUpdateStreakGoal(streakGoal)}
                            className="bg-slate-700 hover:bg-slate-600 text-white px-4 rounded-xl font-medium"
                        >
                            Save
                        </button>
                    </div>
                </div>
             </div>
        </div>
      )}

      {/* Celebration Modal */}
      {showCelebration && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-in zoom-in duration-300">
             <div className="bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700 rounded-3xl p-8 max-w-sm w-full shadow-2xl relative text-center overflow-hidden">
                {/* Background Glow */}
                <div className={`absolute top-0 left-0 w-full h-full ${theme.bg} opacity-10 blur-3xl rounded-full transform scale-150`}></div>
                
                <div className={`w-24 h-24 mx-auto mb-6 rounded-full bg-slate-800 flex items-center justify-center shadow-lg border-2 ${theme.border} animate-bounce-slow`}>
                    <Trophy className={`w-12 h-12 ${theme.primary}`} />
                </div>
                
                <h2 className="text-3xl font-bold text-white mb-2">Goal Reached!</h2>
                <p className="text-slate-300 mb-6">
                    Incredible work, {currentUser.name}! You've hit your <span className={`font-bold ${theme.primary}`}>{streakGoal}-day streak</span>.
                </p>

                <div className="bg-slate-900/50 rounded-xl p-4 mb-6 border border-slate-700/50">
                    <div className="text-xs text-slate-500 uppercase tracking-wider font-bold mb-1">New Streak</div>
                    <div className="text-4xl font-mono font-bold text-white flex items-center justify-center gap-2">
                        <Flame className="w-8 h-8 text-orange-500 fill-orange-500" />
                        {streak}
                    </div>
                </div>

                <button 
                    onClick={() => { setShowCelebration(false); if (mealAdvice === null && elapsedSeconds > 12 * 3600 && isOnline) handleGetMealAdvice(); }}
                    className={`w-full py-4 ${theme.bg} ${theme.bgHover} text-white rounded-xl font-bold shadow-lg transition-all transform hover:scale-[1.02]`}
                >
                    Keep it up!
                </button>
             </div>
        </div>
      )}

      {/* Reminder Modal */}
      {showReminderModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-xs w-full shadow-2xl relative">
                <button onClick={() => setShowReminderModal(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white">
                    <X className="w-5 h-5" />
                </button>
                <div className="flex items-center gap-3 mb-6">
                    <Bell className={`w-6 h-6 ${theme.primary}`} />
                    <h3 className="font-bold text-lg text-white">Daily Reminder</h3>
                </div>
                <div className="space-y-6">
                    <div className="flex items-center justify-between">
                        <span className="text-slate-300">Enable Reminder</span>
                        <button onClick={toggleReminder} className={`w-12 h-6 rounded-full transition-colors relative ${isReminderEnabled ? theme.bg : 'bg-slate-700'}`}>
                            <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${isReminderEnabled ? 'left-7' : 'left-1'}`} />
                        </button>
                    </div>
                    <div className={`transition-opacity ${isReminderEnabled ? 'opacity-100' : 'opacity-40 pointer-events-none'}`}>
                        <label className="block text-xs text-slate-500 uppercase tracking-wider font-semibold mb-2">Remind me at</label>
                        <div className="relative">
                            <input type="time" value={reminderTime} onChange={handleTimeChange} className={`w-full bg-slate-800 border border-slate-600 text-white rounded-xl px-4 py-3 text-lg focus:outline-none focus:ring-1 ${theme.ring} focus:border-transparent`} />
                            <Clock className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5 pointer-events-none" />
                        </div>
                    </div>
                    <button onClick={() => setShowReminderModal(false)} className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-semibold border border-slate-700">Done</button>
                </div>
             </div>
        </div>
      )}

      {/* End Fast Confirmation Modal */}
      {showEndConfirm && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-xs w-full shadow-2xl relative">
                <h3 className="font-bold text-lg text-white mb-2">End Fasting Session?</h3>
                <p className="text-slate-400 text-sm mb-6">
                    You have fasted for <span className="text-white font-medium font-mono">{formatTime(elapsedSeconds)}</span>. 
                    <br/>Are you sure you want to stop?
                </p>
                <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => setShowEndConfirm(false)} className="py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-semibold border border-slate-700">Cancel</button>
                    <button onClick={() => { setShowEndConfirm(false); endFast(); }} className="py-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/50 rounded-xl font-semibold">End Fast</button>
                </div>
             </div>
        </div>
      )}

      {/* Change Protocol Modal */}
      {showProtocolModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-sm w-full shadow-2xl relative max-h-[85vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-lg text-white">Change Protocol</h3>
                    <button onClick={() => setShowProtocolModal(false)} className="p-1 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
                </div>
                <ProtocolSelector selectedId={selectedProtocol.id} onSelect={handleChangeProtocolDuringFast} theme={theme} />
             </div>
        </div>
      )}

      {/* Dashboard Modal */}
      {showDashboard && (
        <CalendarDashboard history={history} journal={journal} onUpdateJournal={handleUpdateJournal} onClose={() => setShowDashboard(false)} theme={theme} />
      )}

      {/* Meal Advice Modal */}
      {showAdviceModal && !showCelebration && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-sm w-full shadow-2xl">
                  <div className={`flex items-center gap-3 mb-4 ${theme.primary}`}>
                      <Utensils className="w-6 h-6" />
                      <h3 className="font-bold text-lg">Breaking Your Fast</h3>
                  </div>
                  <div className="prose prose-invert prose-sm mb-6">
                      {mealAdvice === "Loading advice..." ? (
                          <div className="flex flex-col items-center py-8">
                              <div className={`w-8 h-8 border-2 border-t-transparent rounded-full animate-spin mb-2 ${theme.border}`}></div>
                              <p className="text-slate-400">Generating healthy suggestions...</p>
                          </div>
                      ) : (
                          <div className="whitespace-pre-line text-slate-300">{mealAdvice}</div>
                      )}
                  </div>
                  <button onClick={() => setShowAdviceModal(false)} className={`w-full py-3 ${theme.bg} ${theme.bgHover} text-white rounded-xl font-semibold`}>Got it</button>
              </div>
          </div>
      )}
    </div>
  );
};

export default App;