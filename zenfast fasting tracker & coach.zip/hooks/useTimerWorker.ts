import { useEffect, useRef, useState } from 'react';

const workerCode = `
self.onmessage = function(e) {
  const { command, startTime } = e.data;
  
  if (command === 'START') {
    // Clear any existing interval
    if (self.timerId) clearInterval(self.timerId);
    
    // Immediate tick
    const tick = () => {
      const now = Date.now();
      const elapsed = Math.floor((now - startTime) / 1000);
      self.postMessage(elapsed);
    };
    tick();

    // Start interval
    self.timerId = setInterval(tick, 1000);
  } 
  else if (command === 'STOP') {
    if (self.timerId) clearInterval(self.timerId);
    self.timerId = null;
  }
};
`;

export const useTimerWorker = (startTime: number | null, isFasting: boolean) => {
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const workerRef = useRef<Worker | null>(null);

  useEffect(() => {
    // Create worker from blob
    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const url = URL.createObjectURL(blob);
    const worker = new Worker(url);
    workerRef.current = worker;

    worker.onmessage = (e) => {
      setElapsedSeconds(e.data);
    };

    return () => {
      worker.terminate();
      URL.revokeObjectURL(url);
    };
  }, []);

  useEffect(() => {
    if (!workerRef.current) return;

    if (isFasting && startTime) {
      // Sync immediately on main thread to avoid 1s delay waiting for worker
      setElapsedSeconds(Math.floor((Date.now() - startTime) / 1000));
      
      workerRef.current.postMessage({ 
        command: 'START', 
        startTime 
      });
    } else {
      workerRef.current.postMessage({ command: 'STOP' });
      setElapsedSeconds(0);
    }
  }, [isFasting, startTime]);

  return elapsedSeconds;
};
